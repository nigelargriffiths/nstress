/* Linux ncpu.c part of nstress - a collect of programs to stress test a computer
 * ncpu hammers the CPU(s) but it can back off for user defined percentages.
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>
#include <string.h>
#include <sys/resource.h>
#include <time.h>
#include <sys/time.h>
#include <sys/wait.h>

#define RANGE(min,max) ((long)random() % ((long)(max) - (long)(min) +1L)) + (long)(min)

#define MKSTRING(yyyy) "yyyy"

#define SYSCALL(xxxx) if((xxxx) == -1) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:\n\
File=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", \
__FILE__, __FUNCTION__, __LINE__, MKSTRING(xxxx) ); \
exit(42); \
}

char *progname;
int debug = 0;

void	stop(int sig)
{
	exit(1);
}

void	catch(int sig)
{
	int	stat;

	killpg(getpgrp(), SIGKILL);
	while (wait3(&stat, 0, 0) != (-1)) {
		continue;
	}
	exit(1);
}

double engine(int p1, int p2)
{
	return (double)(p2 + 1) / (double)(p1 + 1);

}

void
work(int snooze,int seconds, int hibernate)
{
	double result = 0;
	struct timeval start;
	struct timeval now;
	double diff;
	double startsec;
	double nowsec;
	double hundredeth; /* 100ths of a second since we started */

	gettimeofday(&start, NULL);
	if(seconds >0)
		alarm(seconds);

	do {
		if(snooze > 0) {
			gettimeofday(&now, NULL);
			startsec = (double)start.tv_sec + 
					((double)start.tv_usec/1000000.0);
			nowsec = (double)now.tv_sec + 
					((double)now.tv_usec/1000000.0);
			diff = nowsec - startsec;

			/*printf("diff=%f\n",diff); */
			hundredeth = diff * 100.0;
			/*printf("100ths=%f\n",hundredeth); */
			if( hundredeth > 100 - snooze) {
				/*printf("usleep\n") */;
				usleep(snooze*10000);
				if( hibernate > 0)
					sleep((int)(RANGE(0,hibernate*2)) );
				gettimeofday(&start, NULL);
			}
		}
		result += engine(RANGE(0,1024*1024),RANGE(0,1024*1024));
	} while (1);
}

void
hint()
{
	printf("Usage: %s version %s hammers the cpu(s)\n",progname, VERSION);
	printf("Note: root users get a priority boost = effectively removes the CPU(s)\n");
	printf("\nHint hammer CPU mode: %s -p procs [-z percent] [-s secs] [-h secs] [-o \"cmd\"]\n",progname);
	printf("\t-p procs   = number of copies of cpu to start (max=256)\n");
	printf("\t-z percent = Snooze percent - time spent sleeping (default 0)\n");
	printf("\t-s seconds = Seconds maximum run time (default no limit)\n");
	printf("\t-h seconds = Seconds to sleep after each second of run time\n");
	printf("\t-o \"cmd\" = Other command - pretend to be this other cmd when running\n");
        printf("\t\tMust be the last option on the line\n");

	printf("\nHint CPU counter mode: %s -c\n\n",progname);
	exit(1);
}

unsigned long
assignment_loop(void)
{
        unsigned long count = 100000000L;
        unsigned long end = 1l;

        while (count-- > end) {
                count = count;
        }
        return count;
}


double process_test(int nprocesses)
{
        struct itimerval timerval_at_start;
        struct itimerval timerval_at_end;
        pid_t   child_pid;
        int     nforked = 0;
        int     nforks = nprocesses - 1;
        char    message[50+1];
        double elapsed_seconds;
        int status;

        /* Start a timer which won't expire before the item being timed
         * completes.  50,000 seconds (over 13 hours) seems reasonable.
         *
         * Can't use the clock() function because (a) it includes the
         * time for child processes and (b) it doesn't seem to include
         * time spent in kernel mode.
         */
        timerval_at_start.it_value.tv_sec = 50000;
        timerval_at_start.it_value.tv_usec = 0;
        setitimer(0, &timerval_at_start, NULL);

        while (nforks-- > 0) {
                switch (child_pid = fork()) {
                        case -1:        perror("fork() failed");
                                                exit(1);
                        case 0:         assignment_loop();
                                                exit(0);
                        default:        /* printf("%d started\n", child_pid); */
                                                nforked++;
                                                break;
                }
        }

        assignment_loop();

        while (nforked-- > 0) {
                wait(&status);
        }

        sprintf(message, "Time for %d process%s",
                        nprocesses, nprocesses == 1 ? "" : "es" );

        getitimer(0, &timerval_at_end);
        elapsed_seconds = timerval_at_start.it_value.tv_usec -
                                        timerval_at_end.it_value.tv_usec;
        elapsed_seconds /= CLOCKS_PER_SEC;
        elapsed_seconds += timerval_at_start.it_value.tv_sec -
                                        timerval_at_end.it_value.tv_sec ;

        printf("%-27s %5.2lf\n", message, elapsed_seconds);
        return elapsed_seconds;
}

void
cpu_counter()
{
        double  single, low, high;
        int     min, max;

	printf(" *** Counting CPUs - this will take a few seconds *** \n");
        single = process_test(1);

        max = 1;
        high = single;

        while (abs(100*high/single - 100) < 5) {
                min = max;
                low = high;
                max *= 2;
                high = process_test(max);
        }

        while (abs(100*low/single - 100) < 5) {
                min++;
                if(max == 2) break;
                low = process_test(min);
        }

        printf("Number of processors is %d\n", min-1);
}

int
main(int argc, char **argv)
{
        int i;
        char command[256];

	int	count_cpus = 0;
	int	procs = 0;
	int	snooze = 0;
	int	seconds = 0;
	int	hibernate = 0;
	pid_t 	pid;
	int ch;
	extern int optind;
	extern char *optarg;

	progname = argv[0];

	while ((ch = getopt(argc, argv, "s:c?p:z:o:h:")) != EOF)
        {
                switch(ch)
                {
                case 'c': count_cpus++; break;
                case 'p': procs = abs(atoi(optarg)); break;
                case 'z': snooze = abs(atoi(optarg)); break;
                case 's': seconds = abs(atoi(optarg)); break;
                case 'h': hibernate = abs(atoi(optarg)); break;
		default:
                case '?': hint(); break;
                case 'o':       if(debug)
                                        printf("link(%s,%s)\n",progname,optarg);
                                SYSCALL(link(progname,optarg) );
                                switch(fork())
                                {
                                case -1: perror("fork failed"); break;
                                case 0: /* child */
                                        strcpy(command,optarg); /* save cmd */
                                        argv[0] = command;
                                        argv[optind-1] = 0; /* remove this option */
                                        argv[optind-2] = 0;
                                        argv[argc] = 0;
                                        if(debug) {
                                                printf("about to exec command \"%s\"\n",command);
                                                for(i=0;i <argc; i++)
                                                        printf("argv[%d]=%s\n",i,argv[i]);
                                        }
                                        SYSCALL( execv(command,argv) );
                                        break;
                                default: /* parent */
                                        break;
                                }
                                sleep(6); /* to allow other process to start bef
ore deleting the link */
                                SYSCALL( unlink(optarg) );
                                return 0;

		}
	}
	if (count_cpus == 0 && procs == 0)
		hint();
	if(count_cpus)
		cpu_counter();

	
	if (count_cpus && procs == 0)
		exit(1);
	if (procs <= 0 || procs >256) {
		printf("ncpu: procs not valid = %d (1 to 256)\n", procs);
		exit(1);
	}
	if (snooze < 0 || snooze >99) {
		printf("ncpu: percent not valid = %d (0 to 100)\n", snooze);
		exit(1);
	}
	setpgid((pid_t)0, (pid_t)0);
	signal(SIGTERM, catch);
	signal(SIGHUP, catch);
	setpriority(PRIO_PROCESS,0,-20);
	srandom(getpid());

	printf("%s - processes=%d snooze=%d%% hibernate=%d secs ",
			progname,procs,snooze,hibernate);
	if(seconds)
		printf("for %d seconds\n",seconds);
	else
		printf("forever\n");

	while (--procs) {
		pid = fork();
		if (pid == 0) {
			signal(SIGTERM, catch);
			signal(SIGALRM, stop);
			work(snooze, seconds, hibernate);
		}
		if (pid < 0) {
			perror("fork() failed");
			exit(1);
		}
	}

	signal(SIGTERM, catch);
	signal(SIGALRM, stop);
	signal(SIGHUP, catch);
	work(snooze, seconds, hibernate);
}
