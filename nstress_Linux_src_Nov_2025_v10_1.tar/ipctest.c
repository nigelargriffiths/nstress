/* Linux ipctest.c part of nstress - a collect of programs to stress test a computer
 * ipctest is a testing program for IPC = Semaphores, Message Queues and Share Memory
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <setjmp.h>
#include <signal.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/msg.h>
#include <sys/sem.h>

main()
{
	printf("IPC Test Package\n");
	printf("----------------\n");

	for(;;)
	{
		switch(getch("memory queues semaphores exit"))
		{
		case 'm':	do_memory();	break;
		case 'q':	do_queue();	break;
		case 's':	do_semaphore();	break;
		case '!':	do_shell();	break;
		case 'e':	return 1;
		}
    	}
}
do_shell()
{
char input[256];

	printf("shell command >");
	gets(input);
	(void)system(input);
	printf("\n-----------------------------------\n");
}
do_queue()
{
	for(;;)
	{
		switch(getch("message queue: get control send receive exit"))
		{
		case 'g':	do_msgget();	break;
		case 'c':	do_msgctl();	break;
		case 's':	do_msgsnd();	break;
		case 'r':	do_msgrcv();	break;
		case 'e':	return;
		}
    	}
}
do_semaphore()
{
	for(;;)
	{
		switch(getch("semaphore: get control operation exit"))
		{
		case 'g':	do_semget();	break;
		case 'c':	do_semctl();	break;
		case 'o':	do_semop();	break;
		case 'e':	return;
		}
    	}
}
do_memory()
{
	for(;;)
	{
		switch(getch("memory: get control attach dettach use exit"))
		{
		case 'g':	do_shmget();	break;
		case 'c':	do_shmctl();	break;
		case 'a':	do_shmat();	break;
		case 'd':	do_shmdt();	break;
		case 'u':	shm_access();	break;
		case 'e':	return;
		}
    	}
}

do_msgctl()
{
int cmd;
int id;
struct msqid_ds buf;

	printf("msgctl()\n");
	id = geti("id");
	cmd = geti("cmd (1=stat 2=set 3=rm)");
	switch(cmd)
	{
	case 1: cmd = IPC_STAT; break;
	case 2: cmd = IPC_SET;
		buf.msg_perm.uid = geti("uid");
		buf.msg_perm.gid = geti("gid");
		buf.msg_perm.mode = geto("mode");
		buf.msg_qbytes    = geti("qbytes");
		  break;
	case 3: cmd = IPC_RMID; break;
	}
	printf("\tmsgctl(id=%d,cmd=%d,buf=0x%x)\n",id,cmd,buf);
	if(msgctl(id,cmd,&buf) == -1)
		perror("msgctl()");
	else
	{
		printf("ok\n");
		if(cmd == IPC_STAT)
		{
		printf("msg_perm.cuid=%d\n",buf.msg_perm.cuid); 
		printf("msg_perm.cgid=%d\n",buf.msg_perm.cgid); 
		printf("msg_perm.uid=%d\n",buf.msg_perm.uid); 
		printf("msg_perm.gid=%d\n",buf.msg_perm.gid); 
		printf("msg_perm.mode=0%o\n",buf.msg_perm.mode); 
		printf("msg_qnum=%d\n",buf.msg_qnum); 
		printf("msg_qbytes=%d\n",buf.msg_qbytes); 
		printf("msg_lspid=%d\n",buf.msg_lspid); 
		printf("msg_lrpid=%d\n",buf.msg_lrpid); 
		printf("msg_stime=%d\n",buf.msg_stime); 
		printf("msg_rtime=%d\n",buf.msg_rtime); 
		printf("msg_ctime=%d\n",buf.msg_ctime); 
		}
	}
}

do_msgget()
{
key_t key;
int id;
int msgflag;

	printf("msgget()\n");
	key = geti("key");
	msgflag = geto("access mode");
	if( getb("create") )
		msgflag |=IPC_CREAT;

	printf("msgget(key=%d,flag=0%o)\n",key,msgflag);

	if((id = msgget(key,msgflag)) == -1)
		perror("msgget()");
	else
		printf("ok, msg id=%d\n",id);
}

#define MESSAGE_LENGTH	500

do_msgsnd()
{
int id;
int size;
int msgflag;
struct message {
		long msg_type;
		char msg_buffer[MESSAGE_LENGTH];
		} msg;


	printf("msgsnd()\n");
	id = geti("id");
	msg.msg_type = geti("message type number");

	printf("message data >");
	(void)gets( msg.msg_buffer);
	printf("data size is %d and total buffer size is %d\n",
		strlen(msg.msg_buffer),sizeof(msg.msg_buffer));
	size = geti("size to send");

	if(getb("wait"))
		msgflag =0;
	else
		msgflag = IPC_NOWAIT;

	printf("\tmsgsnd(id=%d,msg=0x%x,size=%d,flag=0%o)\n",
		id,&msg,size,msgflag);

	if(msgsnd(id,&msg,size,msgflag) != 0)
		perror("msgsnd()");
	else
		printf("ok\n");
}

do_msgrcv()
{
int id;
int size;
int type;
int count;
int msgflag;
struct message {
		long msg_type;
		char msg_buffer[MESSAGE_LENGTH];
		} msg;


	printf("msgrcv()\n");
	id = geti("id");
	size = geti("message size (max 500)");
	type = geti("message type number");

	if(getb("wait"))
		msgflag =0;
	else
		msgflag = IPC_NOWAIT;

	if( !getb("truncatable") )
		msgflag |= MSG_NOERROR;

	/* corrupt the buffer so we know if data arrived */
	msg.msg_type = -123;
	msg.msg_buffer[0] = 0;

	printf("\tmsgrcv(id=%d,msg=0x%x,size=%d,type=%d,flag=0%o)\n",
		id,&msg,size,type,msgflag);

	if(( count = msgrcv(id,&msg,size,type,msgflag)) < 0)
		perror("msgrcv()");
	else
		printf("ok, %d characters recieved, type=%d, data=\"%s\"\n",
			count, msg.msg_type, msg.msg_buffer);
}

do_semctl()
{
int cmd;
int index;
int num;
int id;
int i;
struct semid_ds semds;
ushort id_array[20];
union semun {
	int val;
	struct semid_ds *buf;
	ushort *array;
	} arg;

	id = geti("id");
	num = geti("no of semaphore(s)");
	index = geti("cmd (1=getval 2=setval 3=getpid 4=getncnt 5=getzcnt \n\t6=getall 7=setall 8=ipc_stat 9=ipc_set 10=ipc=rmid)");
	switch(index)
	{
	case 1: cmd = GETVAL; 
		arg.array = &id_array[0];
		break; 
	case 2: cmd = SETVAL; 
		arg.array = &id_array[0];
		for( i = 0; i < num;i++)
			arg.array[i] = geti("semaphore number");
		break; 
	case 3: cmd = GETPID; break; 
	case 4: cmd = GETNCNT; break; 
	case 5: cmd = GETZCNT; break; 
	case 6: cmd = GETALL; break; 
	case 7: cmd = SETALL; break; 
	case 8: cmd = IPC_STAT; 
		arg.buf = &semds; 
		break;
	case 9: cmd = IPC_SET;  
		arg.buf->sem_perm.uid = geti("uid");
		arg.buf->sem_perm.gid = geti("gid");
		arg.buf->sem_perm.mode = geto("mode");
		break;
	case 10: cmd = IPC_RMID; break;
	}
	printf("\tsemctl(id=%d,num=%d,cmd=%d,arg=0x%x)\n",id,num,cmd,&arg);
	if(semctl(id,num,cmd,&arg) == -1)
		perror("semctl()");
	else
	{
		printf("ok\n");
	switch(index)
	{
	case 1: printf("semval=%d\n",arg.val); break; 
	case 2: break; 
	case 3: printf("sempid=%d\n",arg.val); break;
	case 4: printf("semncnt=%d\n",arg.val); break;
	case 5: printf("semzcnt=%d\n",arg.val); break;
	case 6: for(i = 0; i < num;i++)
			printf("semval[i]=%d\n",i,arg.array[i]); 
		break;
	case 7: break;
	case 8: 
		printf("sem_perm.cuid=%d\n",arg.buf->sem_perm.cuid); 
		printf("sem_perm.cgid=%d\n",arg.buf->sem_perm.cgid); 
		printf("sem_perm.uid=%d\n",arg.buf->sem_perm.uid); 
		printf("sem_perm.gid=%d\n",arg.buf->sem_perm.gid); 
		printf("sem_perm.mode=0%o\n",arg.buf->sem_perm.mode); 
		printf("sem_nsems=%d\n",arg.buf->sem_nsems); 
		printf("sem_otime=%d\n",arg.buf->sem_otime); 
		printf("sem_ctime=%d\n",arg.buf->sem_ctime); 
		break;
	case 9: break;
	case 10: break;
	}
	}
}

do_semget()
{
int id;
int num;
key_t key;
int semflag;

printf("semget()\n");
	key = geti("key");
	num = geti("no of semaphore(s)");

	semflag = geto("access mode") ;
	if( getb("create") )
		semflag |= IPC_CREAT;
	if( getb("exclusive") )
		semflag |= IPC_EXCL;

	printf("semget(key=%d,num=%d,flag=0%o)\n",key,num,semflag);

	if((id = semget(key,num,semflag)) == -1)
		perror("semget()");
	else
		printf("ok, semaphore id=%d\n",id);
}

do_semop()
{
int num;
int i;
int id;
struct sembuf sem[20];

	id = geti("id");
	num = geti("no of semaphore(s) in array");
	for(i = 0; i < num; i++)
	{
		printf("set up semaphore item %d\n",i);
		sem[i].sem_num = geti("semaphore number");
		sem[i].sem_op  = geti("semaphore operation");
		if(getb("semaphore flags CREATE"))
			sem[i].sem_flg = IPC_CREAT;
		else
			sem[i].sem_flg = 0;
		if(getb("semaphore flags UNDO"))
			sem[i].sem_flg != SEM_UNDO;
	}
	printf("semop(id=%d,sem=0x%x,num=%d)\n",id,sem,num);
	if(semop(id,sem,num) == -1)
		perror("semop()");
	else
		printf("ok\n");
}

do_shmctl()
{
int cmd;
int id;
struct shmid_ds buf;

printf("shmctl()\n");
	id = geti("id");
	switch(geti("cmd (1=stat 2=set 3=rm)"))
	{
	case 1: cmd = IPC_STAT; break;
	case 2: cmd = IPC_SET;  
		buf.shm_perm.uid = geti("uid");
		buf.shm_perm.gid = geti("gid");
		buf.shm_perm.mode = geto("mode");
		break;
	case 3: cmd = IPC_RMID; break;
	}
	printf("\tshmctl(id=%d,cmd=%d,buf=0x%x)\n",id,cmd,buf);
	if(shmctl(id,cmd,&buf) == -1)
		perror("shmctl()");
	else
	{
		printf("ok\n");
		if(cmd == IPC_STAT)
		{
		printf("shm_perm.cuid=%d\n",buf.shm_perm.cuid); 
		printf("shm_perm.cgid=%d\n",buf.shm_perm.cgid); 
		printf("shm_perm.uid=%d\n",buf.shm_perm.uid); 
		printf("shm_perm.gid=%d\n",buf.shm_perm.gid); 
		printf("shm_perm.mode=0%o\n",buf.shm_perm.mode); 
		printf("shm_segsz=%d\n",buf.shm_segsz); 
		printf("shm_cpid=%d\n",buf.shm_cpid); 
		printf("shm_rpid=%d\n",buf.shm_lpid); 
		printf("shm_nattch=%d\n",buf.shm_nattch); 
		printf("shm_atime=%d\n",buf.shm_atime); 
		printf("shm_dtime=%d\n",buf.shm_dtime); 
		printf("shm_ctime=%d\n",buf.shm_ctime); 
		}
	}
}

do_shmget()
{
int id;
int shmflag;
int size;
key_t key;

	printf("shmget()\n");
	key = geti("key");
	size = geti("size");
	shmflag = geto("access mode");
	if( getb("create"))
		shmflag |= IPC_CREAT;
	if( getb("private"))
		shmflag |= IPC_PRIVATE;

	printf("shmget(key=%d,size=%d,flag=0%o)\n", key,size,shmflag);

	if((id = shmget(key,size,shmflag)) == -1)
		perror("shmget()");
	else
		printf("ok, memory id=%d\n",id);
}


do_shmat()
{
int flag;
int id;
char *address;

printf("shmget()\n");
	id = geti("id");
	address = (char *)getx("address");
	flag = 0;
	if( getb("read only") )
		flag = SHM_RDONLY;
	if( getb("round up ") )
		flag = flag | SHM_RND;

	printf("shmat(id=%d,address=0x%x,flag=0%o)\n", id,address,flag);

	if((address = (char *)shmat(id,address,flag)) == (char *)-1)
		perror("shmat()");
	else
		printf("ok, address is %d (0x%x)\n",address,address);
}


do_shmdt()
{
char *address;

printf("shmdt()\n");
	address = (char *)getx("address");
	printf("shmdt(0x%x)\n",address);
	if(shmdt(address) == -1)
		perror("shmdt()");
	else
		printf("ok");
}

jmp_buf jumper;


void
memory_fault(int x)
{
	printf("Memory_fault\n");
	longjmp(jumper,1);
}

shm_access()
{
char *address;
int size;
char input[256];

	if(setjmp(jumper) != 0)
		printf("\nrecovered from memory fault\n\n");
	signal(SIGBUS, memory_fault);
	signal(SIGSEGV,memory_fault);
	for(;;)
	{
		switch( getch("memory access: read write exit") )
		{
		case 'w': 
			address = (char *)getx("address");
			set_buf(address);
			break;
		case 'r': 
			address = (char *)getx("address");
			size = geti("size");
			printb(address,size);
			break;
		case 'e': return;
		}
	}
}
