/* Linux semlib.c part of nstress - a collect of programs to stress test a computer
 * Shared semaphore library function part of IPC tests
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h>

int sid;
extern int debug;

void
semaphore_fetch(key,locks)
int key;
int locks;
{
	key_t semkey;
	int semflag;

	semkey = key;
	semflag = 0666;

	if((sid = semget(semkey,locks,semflag)) == -1)
	{
		perror("semaphore_fetch()");
		exit(1);
	}
}

void
semaphore_make(key,locks)
int key;
int locks;
{
	key_t semkey;
	int semflag;

	if(key == 0)
		semkey = IPC_PRIVATE;
	else
		semkey = key;
	semflag = 0666 | IPC_CREAT;

	if((sid = semget(semkey,locks,semflag)) == -1)
	{
		perror("semaphore_make()");
		exit(1);
	}
}

void
semaphore_delete(int report_error)
{
int ret = semctl(sid,0,IPC_RMID,1);
	if( report_error && ret == -1)
	{
		if(debug)perror("semaphore_delete()");
		exit(2);
	}
}

void
semaphore_set(lock,num)
int lock;
int num;
{
	if(semctl(sid,lock,SETVAL,num) == -1)
	{
		perror("semaphore_set()");
		exit(2);
	}
}

void
semaphore_lock(lock)
int lock;
{
struct sembuf sem[1];

	sem[0].sem_num = lock;
	sem[0].sem_flg = 0;
	sem[0].sem_op  = -1;
	if(semop(sid,sem,1) == -1)
	{
		perror("semaphore_lock()");
		exit(3);
	}
}

void
semaphore_unlock(lock)
int lock;
{
struct sembuf sem[1];

	sem[0].sem_num = lock;
	sem[0].sem_flg = 0;
	sem[0].sem_op  = 1;
	if(semop(sid,sem,1) == -1)
	{
		perror("semaphore_unlock()");
		exit(4);
	}
}
