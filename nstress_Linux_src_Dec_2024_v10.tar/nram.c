/* Linux nram.c part of nstress - a collect of programs to stress test a computer
 * nram tests memory speed
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
/* #include <macros.h> */
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>

#define RANGE(min,max) ((long)random() % ((long)(max) - (long)(min) +1L)) + (long)(min)

#define MAPFILENAME	"tempfile_2MB"
#define MAPFILESIZE	2*1024*1024
#define MAXMEMSIZE	256 /* in MBytes */

#ifndef TRUE
#define TRUE 1
#endif 

#ifndef FALSE
#define FALSE 0
#endif 

#define MKSTRING(yyyy) "yyyy"

#define SYSCALL(xxxx) if((xxxx) == -1) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", __FILE__, __FUNCTION__, __LINE__, MKSTRING(xxxx) ); \
exit(42); \
} 

#define SYSCALL_FILENAME(xxxx) if((xxxx) == -1) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", __FILE__, __FUNCTION__, __LINE__, MKSTRING(xxxx) ); \
fprintf(stderr,"Filename=\"%s\"\n", filename ); \
exit(42); \
} 

#define NOTNULL(xxxx) if((xxxx) == NULL) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: NULL not returned:\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", __FILE__, __FUNCTION__, __LINE__, MKSTRING(xxxx) ); \
exit(42); \
} 

#define DEBUG1(xxxx)  if(debug > 1) { fprintf(stderr,"Debug1: Function=%-20s, Line=%d ", __FUNCTION__, __LINE__); xxxx } 
#define DEBUG2(xxxx)  if(debug > 2) { fprintf(stderr,"Debug2: Function=%-20s, Line=%d ", __FUNCTION__, __LINE__); xxxx } 
#define DEBUG3(xxxx)  if(debug > 3) { fprintf(stderr,"Debug3: Function=%-20s, Line=%d ", __FUNCTION__, __LINE__); xxxx } 

#define LOGNUM(name,p1,p2,p3) \
if(logging) { \
if(logfp == 0) { \
		char logname[128]; \
		sprintf(logname,"%d.log",getpid()); \
		logfp = fopen( logname, "w"); \
} \
fprintf(logfp,"%s(%ld,%ld,%ld) File=%s, Function=%s, Line=%d\n", name,(long)p1,(long)p2,(long)p3,__FILE__, __FUNCTION__, __LINE__  ); \
} 

#define LOGSTR(name,p1,p2,p3) \
if(logging) { \
if(logfp == 0) { \
		char logname[128]; \
		sprintf(logname,"%d.log",getpid()); \
		logfp = fopen( logname, "w"); \
} \
fprintf(logfp,"%s(%s,%s,%s) File=%s, Function=%s, Line=%d\n", name,p1,p2,p3,__FILE__, __FUNCTION__, __LINE__  ); \
} 

int debug = 0;
int verbose = 0;
int logging = 0;
FILE *logfp;

/*Shared memory variable */
#define SHMKEY_PARALLEL	0xdeadbeef
#define SHMKEY_DATA	0xbeefdead
#define PERMS 0666
char *shm_address = 0;
key_t shmid_parallel;
key_t shmid_data;
int shm_mb = 0;

unsigned int	not_interrupted;
unsigned int	iterations;
unsigned int	seconds = 5;
unsigned int	sleep_secs = 5;

struct itimerval timerval_at_start;
struct itimerval timerval_at_end;
struct timeval starting;
struct timeval ending;
double	elapsed;


void
sig_handler(int signum)
{
	DEBUG1( fprintf(stderr, "sig_handler(signum= %d)\n",signum); );
	not_interrupted = FALSE;
	signal(SIGALRM, sig_handler);
}

void
start_countup_timer(void)
{
	/* Start a timer which won't expire before the item being timed
	 * completes.  50,000 seconds (over 13 hours) seems reasonable.
	 *
	 * Can't use the clock() function because (a) it includes the
	 * time for child processes and (b) it doesn't seem to include
	 * time spent in kernel mode.
	 */
	gettimeofday(&starting, NULL);
	timerval_at_start.it_value.tv_sec = 50000;
	timerval_at_start.it_value.tv_usec = 0;
	setitimer(0, &timerval_at_start, NULL);
}

void
stop_countup_timer_and_print(const char * message)
{
double elapsed_seconds;
	/* Alarm was never set - display how long elapsed before this
	 * function was called instead of printing out the number of
	 * iterations the loop went through.
	 */

	getitimer(0, &timerval_at_end);
	elapsed_seconds = timerval_at_start.it_value.tv_usec -
					timerval_at_end.it_value.tv_usec;
	elapsed_seconds /= CLOCKS_PER_SEC;
	elapsed_seconds += timerval_at_start.it_value.tv_sec -
					timerval_at_end.it_value.tv_sec ;
	printf("%-24s ", message);
	printf("   %5.2lf\n", elapsed_seconds);
}
void
start_timer(void)
{
	DEBUG3(printf("start_timer()\n"););
	gettimeofday(&starting, NULL);
	iterations = 0;
	not_interrupted = TRUE;
	signal(SIGALRM, sig_handler);
	alarm(seconds);
}

void
stop_timer_and_print(const char * message)
{
	gettimeofday(&ending,NULL);
	elapsed = (double)(ending.tv_sec - starting.tv_sec) + 
		  (double)((ending.tv_usec - starting.tv_usec))/1000000.0;
	printf("%-24s ", message);
	printf("  %12.2f ops/sec [%.1f seconds]\n", 
			iterations/elapsed, elapsed);
}

void
start_banner(const char * message)
{
	printf("*** Start %-20s ***\n", message);
}

void
end_banner(void)
{
}

void
make_a_file(char *filename, unsigned long file_size)
{
int fd;
int i;
char buf[4096];

	DEBUG1( fprintf(stderr,"called make_a_file(filename=%s,size=%ld)\n",filename,file_size); );

	printf("Creating file %s size=%ld (%ldKB or %ldMB)\n",
			filename,file_size, (long)(file_size/1024),
			(long)(file_size/1024/1024));
	LOGSTR("open",filename,"O_RDWR|O_CREATE","0666");
        SYSCALL_FILENAME( fd = open(filename, O_RDWR | O_CREAT, 0666) );

        for(i=0; i<file_size/1024/4; i++) {
		LOGNUM("write",fd,buf,4096);
		SYSCALL( write(fd, buf, 4096) );
	}
	LOGNUM("close",fd,-9,-9);
        SYSCALL( close(fd) );
	sync();
}

void
disk_setup_bigfile(char *filename, unsigned long file_size)
{
	struct stat	statbuf;

	DEBUG1( fprintf(stderr,"called disk_setup_bigfile(filename=%s, size=%ld)\n",filename,file_size); );

	/* Find out the size of the file to make sure its big enough  */
	if( stat(filename, &statbuf) != -1 &&
	    statbuf.st_size >= file_size)
		return;

	unlink(filename); 
	make_a_file(filename,file_size);
}

void
check_file_exists(char *filename)
{
int fd;
	fd = open(filename, O_RDWR, 0);
	if(fd == -1) {
		printf("File %s does not exist.\nUse -C option to create large files\n",filename);
		exit(345);
	}
	close(fd);
}

/* MEMORY MAPPED FILE */
#define MAPPED_ARRAY_SIZE	500000

void
memory_mapped_file(void)
{
	int fd;
	char filename[64];
	int *	mptr;
	int	mapped_segment_size	= MAPPED_ARRAY_SIZE*sizeof(*mptr);

	DEBUG1( fprintf(stderr,"called disk_test_memory_mapped()\n"); );
	disk_setup_bigfile(MAPFILENAME, MAPFILESIZE);
	strcpy(filename,MAPFILENAME);
	SYSCALL_FILENAME(fd = open(MAPFILENAME, O_RDWR, 0));
	mptr = (int *) mmap(0,
			mapped_segment_size,
			PROT_READ|PROT_WRITE, 
			MAP_SHARED,
			fd,
			0);

	if (mptr == (int *) -1) {
		perror("Could not map file");
	}
	else {
		start_timer();
		while (not_interrupted) {
			iterations++;
			mptr[0]++;
			mptr[MAPPED_ARRAY_SIZE - 1]++;

			SYSCALL( msync(mptr, mapped_segment_size, MS_SYNC) );
		}
		stop_timer_and_print("Mapped file 2MB sync's");
		SYSCALL( munmap(mptr, mapped_segment_size) );
	}
	SYSCALL( close(fd) );
}

/* RAM */

/* Required for pseudo-random number generation in memory tests.  */
#define FACTOR	6553600

void
memory_test(void)
{
	unsigned int	factor;
	unsigned int	i = 0, j = 0;
	unsigned long	initial_count = 4000000L;
	register int	reg = 0;
	int *mptr;
	int *init_ptr;
	int  dummy_var;

	start_banner("Memory test");

	if ((mptr = (int *) malloc(FACTOR*sizeof(*mptr))) == NULL)
	{
		fprintf(stderr, "malloc() failed\n");
		exit(1);
	}

	init_ptr = mptr + FACTOR - 1;
	while (init_ptr >= mptr)
	{
		*init_ptr-- = 0;
	}

	start_timer();
	factor=1;
	while (not_interrupted)
	{
		iterations++;
		i = i*factor + 1;
		j = i%FACTOR;
		dummy_var = mptr[j];
	}
	stop_timer_and_print("Sequential memory read:");

	init_ptr = mptr + FACTOR - 1;
	while (init_ptr >= mptr)
	{
		*init_ptr-- = 0;
	}

	start_timer();
	factor=171;

	while (not_interrupted)
	{
		iterations++;
		i = i*factor + 17;
		j = i%FACTOR;
		dummy_var = mptr[j];
	}
	stop_timer_and_print("Random memory read:");

	init_ptr = mptr + FACTOR - 1;
	while (init_ptr >= mptr)
	{
		*init_ptr-- = 0;
	}

	start_timer();
	factor=1;
	
	while (not_interrupted)
	{
		iterations++;
		i = i*factor + 1;
		j = i%FACTOR;
		mptr[j] = dummy_var;
	}
	stop_timer_and_print("Sequential memory write:");

	init_ptr = mptr + FACTOR - 1;
	while (init_ptr >= mptr)
	{
		*init_ptr-- = 0;
	}

	start_timer();
	factor=171;
	
	while (not_interrupted)
	{
		iterations++;
		i = i*factor + 17;
		j = i%FACTOR;
		mptr[j] = dummy_var;
	}
	stop_timer_and_print("Random memory write:");

	init_ptr = mptr + FACTOR - 1;
	while (init_ptr >= mptr)
	{
		*init_ptr-- = 0;
	}

	start_timer();
	
	while (not_interrupted)
	{
		iterations++;
		reg = mptr[j];
	}
	stop_timer_and_print("Repeated fixed read:");

	init_ptr = mptr + FACTOR - 1;
	while (init_ptr >= mptr)
	{
		*init_ptr-- = 0;
	}

	start_timer();
	
	while (not_interrupted)
	{
		iterations++;
		mptr[j] = 0;
	}
	stop_timer_and_print("Repeated fixed write:");

	end_banner();
}

char *progname;

void
print_usage_message(void)
{
	fprintf(stderr, "Usage: for %7s version %s\n\
Simple Tests\n\
%7s -m          Memory test\n\
        -y          Memory Mapped files & file create (uses %s file)\n\
        -a          All above tests\n\
General Options works in Simple and Disk test modes\n\
%7s -t <secs>   Timed duration of the test in seconds (default 5)\n\
        -v          Verbose mode = gives extra stats but slower\n\
        -l          Loging disk I/O mode = see *.log but slower still\n\
        -o \"cmd\"  Other command - pretend to be this other cmd when running\n\
                        Must be the last option on the line\n\n"
,progname, VERSION,progname,MAPFILENAME,progname);
}


int
main(int argc, char** argv)
{
	int attached = 0;
	char *str;
	int i;
	int t;
	char filename[1024] = {0};
	int mb = 32;
	int ch;
	int need_usage_message = FALSE;
	int do_memory = FALSE;
	int do_other = FALSE;
	int quiet = FALSE;
	int pid;
	int status;
	char command[256];

	if(getenv("NSTRESS_DEBUG") != NULL) {
		debug = atoi(getenv("NSTRESS_DEBUG"));
		printf("debug level set to %d\n",debug);
	}

	if(getenv("NSTRESS_RANDOM") != NULL) 
		srandom(atoi(getenv("NSTRESS_RANDOM")));
	else
		srandom(getpid());

	progname = argv[0];

	while ((ch = getopt(argc, argv, "ymat:lvko:")) != -1)
	{
		switch(ch)
		{
		case 'o':	if(debug) 
					printf("link(%s,%s)\n",progname,optarg);
				SYSCALL(link(progname,optarg) );
				switch(fork())
				{
				case -1: perror("fork failed"); break;
				case 0: /* child */
					strcpy(command,optarg); /* save cmd */
					argv[0] = command;
					argv[optind-1] = 0; /* remove this option */
					argv[optind-2] = 0; 
					argv[argc] = 0;
					if(debug) {
						printf("about to exec command \"%s\"\n",command);
						for(i=0;i <argc; i++)
							printf("argv[%d]=%s\n",i,argv[i]);
					}
					SYSCALL( execv(command,argv) );
					break;
				default: /* parent */
					break;
				}
				sleep(6); /* to allow other process to start before deleting the link */
				SYSCALL( unlink(optarg) );
				return 0;
		case '?':	print_usage_message();
				return 0;

		case 'k':	quiet = TRUE; break;

		case 'y':	do_other = TRUE; break;

		case 'm':	do_memory = TRUE; break;

		case 'v':	verbose = TRUE; break;
		case 'l':	logging = TRUE; break;

		case 't':	seconds = atoi(optarg); 
				break;

		case 'a':	
				do_memory = TRUE;
				do_other = TRUE;
				break;
		}
	}

	if(!quiet) {
		printf("\tVersion %s: ", VERSION);

		for(i=0;i<argc;i++)
			printf("%s ",argv[i]);
		printf("\n");
	}

	/* Print out the usage message if (a) an unknown flag was used on the
	 * command line, (b) there were no arguments or (c) there were arguments
	 * which were not flags like -p or whatever.
	 */
	if (need_usage_message || argc == 1 || optind < argc) {
		print_usage_message();
		exit(2);
	}
	if (do_memory ) 
		printf("Run test for %d seconds\n",seconds);
	if (do_memory) {
		memory_test();
	}
	return 0;
}
