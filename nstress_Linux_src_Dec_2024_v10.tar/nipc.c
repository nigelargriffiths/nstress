/* Linux nipc.c part of nstress - a collect of programs to stress test a computer
 * nipc tests the Inter-process Communications Shared memory, Semaphores and Message Queue
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <sys/signal.h>

char *gets();
char *strcat();

#define XLOGGING 1
#define MAX_SIZE 8*1024*1024


int debug = 0;

#define __MKSTRING(yyyy) "yyyy"

#define SYSCALL(xxxx) if((xxxx) == -1) { \
perror( "ERROR"); \
	fprintf(stderr,"Assert failure: SYSCALL retured  -1:\n File=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", \
	__FILE__, __FUNCTION__, __LINE__, __MKSTRING(xxxx) ); \
exit(42); \
}


extern void semaphore_make(int, int);
extern void semaphore_set(int, int);
extern void semaphore_lock(int);
extern void semaphore_unlock(int);
extern void semaphore_delete(int);

extern void memory_create(int, int);
extern void memory_read(char *);
extern void memory_write(char *);
extern void memory_delete(int);

extern void message_create(int);
extern void message_send(int, char *, int);
extern int  message_recv(int, char *, int);
extern void message_delete(int);


void sig(int x)
{
	semaphore_delete(0);
	memory_delete(0);
	message_delete(0);
	exit(0);
}

void
nzap()
{
        FILE *fp;

        fp = fopen("nzap","a");
        fprintf(fp,"kill -1 %d\n",getpid());
        fclose(fp);
}

void
zap(char *ptr)
{
int i;
	for(i=0;i<MAX_SIZE;i++)
		ptr[i] = 0;
}

void
hint(char *str)
{
	if(str)printf("nipc:%s\n",str);
	printf("Usage: nipc version %s\n", VERSION);
	printf("nipc: hammers inter-process communication (IPC)\n");
	printf("      that is shared memory, semaphores and message queues\n");
	printf("hint: nipc -p procs -s seconds\n");
	exit(3);
}

void
work(char id, int lockid, int unlockid, int seconds)
{
int i;
char msgbuf[MAX_SIZE];
char membuf[MAX_SIZE];
int size;
char addstr[3];

	addstr[0] = id;
	addstr[1] = 0;

	nzap();
	signal(SIGHUP,sig);
	signal(SIGALRM,sig);
	if(seconds > 0) 
		alarm(seconds);

	for( i = 0; ;i++)
	{
		/* wait till my turn */
		semaphore_lock(lockid);

		/* get message and read memory */
		size = message_recv(0,msgbuf,MAX_SIZE);
		memory_read(membuf);

		/* compare them */
		if( strcmp(msgbuf,membuf) != 0)
		{
		printf("Error on Loop=%d Process=%c size=%d\n",i,id,size);
		printf("The buffers are different\n");
		printf("msg    size=%d \"%s\"\n", size, msgbuf);
		printf("memory size=%ld \"%s\"\n", strlen(membuf), membuf);
		exit(44);
		}
#ifdef LOGGING
		else
			printf("Loop=%d Process=%c size=%d\n",i,id,size);
#endif

		if(size >= MAX_SIZE -2) {
			zap(msgbuf);
			zap(membuf);
			if(debug)printf("Zapped: Loop=%d Process=%c size=%d\n",i,id,size);
		}
		/* send message and set memory for next process */
		(void)strcat(msgbuf,addstr);
		message_send(1,msgbuf,strlen(msgbuf));

		(void)strcat(membuf,addstr);
		memory_write(membuf);

		/* release next process */
		semaphore_unlock(unlockid);
	}
	if(debug)printf("Exit on Loop=%d Process=%c size=%d\n",i,id,size);
	sig(1);
	exit(0);
}


int
main(int argc, char **argv)
{
int i;
int procs = 2;
char command[256];
int seconds = 0;
int ch;
char *progname;

	procs    = 2;

	progname = argv[0];

	while ((ch = getopt(argc, argv, "h?p:s:o:")) != -1)
        {
                switch(ch)
                {
                case '?':
                case 'h': hint((char *)0);
                          break;
                case 'p': procs = atoi(optarg); 
				if(procs < 2)
					hint("more processes please");
			  break;
                case 's': seconds = atoi(optarg); 
				if(procs < 0)
					hint("seconds arg must be positive");
			  break;
                case 'o':       if(debug)
                                        printf("link(%s,%s)\n",progname,optarg);
                                SYSCALL(link(progname,optarg) );
                                switch(fork())
                                {
                                case -1: perror("fork failed"); break;
                                case 0: /* child */
                                        strcpy(command,optarg); /* save cmd */
                                        argv[0] = command;
                                        argv[optind-1] = 0; /* remove this option */
                                        argv[optind-2] = 0;
                                        argv[argc] = 0;
                                        if(debug) {
                                                printf("about to exec command \"%s\"\n",command);
                                                for(i=0;i <argc; i++)
                                                        printf("argv[%d]=%s\n",i,argv[i]);
                                        }
                                        SYSCALL( execv(command,argv) );
                                        break;
                                default: /* parent */
                                        break;
                                }
                                sleep(6); /* to allow other process to start before deleting the link */
                                SYSCALL( unlink(optarg) );
                                return 0;

                }
        }


	/* create and set up all the resources */
	semaphore_make(0,procs);
	semaphore_set(0,1);

	for( i = 1; i < procs; i++)
		semaphore_set(1,0);

	memory_create(0,MAX_SIZE);
	memory_write("");

	message_create(0);
	message_send(1,"",1);

	fflush(0);

	for( i = 0; i < procs; i++)
	{
		switch( fork() )
		{
		case  0: /* child */
			 if( i == procs -1)
			 	work('a'+i, i, 0, seconds); /* last one is 
								    special */
			 else
				work('a'+i, i, i+1, seconds); 
			 break;
		case -1: /* error */
			 printf("fork failed\n"); 
			 return 1;
		default: /* parent */
			 break;
		}
	}

	return 0;
}

