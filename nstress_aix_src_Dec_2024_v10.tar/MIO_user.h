#if !defined(_MIO_IO_USER_H)
#define _MIO_IO_USER_H

#define _LARGE_FILES
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>

int MIO_error ;

extern int MIO_open64();
extern int MIO_fstat64();
extern off_t MIO_lseek64(int,off_t,int);
extern int MIO_ftruncate64(int,off_t);
extern int MIO_read();
extern int MIO_write();
extern int MIO_close();
extern int MIO_fcntl();
extern int MIO_ffinfo();
extern int MIO_fsync();
extern int64 MIO_str_to_long();

#if defined(USE_MIO_DEFINES)
#define open64(a,b,c)    MIO_open64(a,b,c,0)
#define close(a)         MIO_close(a)
#define read(a,b,c)      MIO_read(a,b,c)
#define write(a,b,c)     MIO_write(a,b,c)
#define lseek64(a,b,c)   MIO_lseek64(a,b,c)
#define ftruncate64(a,b) MIO_ftruncate64(a,b)
#define fsync(a)         MIO_fsync(a)
#define fstat64(a,b)     MIO_fstat64(a,b)
#define ffinfo(a,b,c,d)  MIO_ffinfo(a,b,c,d)
#define fcntl(a,b,c)     MIO_fcntl(a,b,c)
#endif

#define MIO_EXTRA_COOKIE 0x7a78746b
struct mio_extra {
   int   cookie ;
   int64 bufsiz ;
   int   taskid ;
   char *modules ;
   char *logical_name ;
} ;
#endif
