/* nfile.c part of nstress - a collect of programs to stress test a computer
 * nfile created and removes files and directories to stress the file system.
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <dirent.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <dirent.h>

#define RANGE(min,max) ((long)random() % ((long)(max) - (long)(min) +1L)) + (long)(min)

#define __STRING(yyyy) "yyyy"

#define SYSCALL(xxxx) if((xxxx) == -1) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:\nFile=%s, Function=%s, Line=%d,\
nOperation=\"%s\"\n", __FILE__, __FUNCTION__, __LINE__, __STRING(xxxx) ); \
exit(42); \
}


/* arrays to track valid files */

int files[26][26][26];

int interrupted = 0;

char *progname;

int debug = 0;
#define DEBUG1 if(debug == 1)
#define DEBUG2 if(debug == 2)

void sighandler(int x)
{
	interrupted = 1;
}


/*
files/a/a/a
*/

void create_dirs( char *directory)
{
int i,j;
char str[256];

	DEBUG1 printf("create_dirs(%s)\n",directory);
	DEBUG1 printf("create_dirs - create first level\n");
	for(i = 'a'; i <= 'z'; i++) {
		sprintf(str, "%s/%c",directory,i);
		if ( mkdir(str,0777) == -1 && errno != EEXIST){
			perror("mkdir failure");
			printf("directory = %s errno=%d\n",str,errno);
			exit(3);
		}
	}
	DEBUG1 printf("create_dirs - create second level\n");
	for(i = 'a'; i <= 'z'; i++)
	for(j = 'a'; j <= 'z'; j++) {
		sprintf(str, "%s/%c/%c",directory,i,j);
		if ( mkdir(str,0777) == -1 && errno != EEXIST){
			perror("mkdir failure");
			printf("directory = %s errno=%d\n",str,errno);
			exit(4);
		}
	}
	DEBUG1 printf("create_dirs - done\n");
}

int *
read_filenames(char *directory)
{
DIR *dir;
struct dirent *dp;
int i,j,k;
char str[256];;

	DEBUG1 printf("searching directory \"%s\"\n",directory);
	str[1] = 0;

	for(i = 'a'; i <= 'z'; i++)
	for(j = 'a'; j <= 'z'; j++) { 
		sprintf(str, "%s/%c/%c",directory,i,j);

		if((dir = opendir(str)) == NULL) {
			printf("directory %s not found\n",str);
			exit(5);
		}
		while( (dp = readdir(dir)) != NULL ) {
			if( !strcmp(dp->d_name, ".") ||
				 !strcmp(dp->d_name,"..") ) {
				continue;
			}
			if( dp->d_name[0] >= 'a' &&
			    dp->d_name[0] <= 'z' &&
			    dp->d_name[1] == 0) {
				DEBUG1 printf("found \"%s/%s\"\n",str,dp->d_name);
				files[i - 'a'][j - 'a'][dp->d_name[0] - 'a'] = -1;
			}
		}
	}
	DEBUG1 printf("searching directory - done\n");
}

void
create_file(char *directory,int size)
{
int i,k,j;
FILE *fp;
char str[256];

	DEBUG1 printf("create_file(%s,size=%d)\n",directory,size);
	do {
		i=RANGE('a','z');
		j=RANGE('a','z');
		k=RANGE('a','z');
	} while(files[i][j][k] == -1 );
	
	files[i][j][k] = -1;
	sprintf(str, "%s/%c/%c/%c",directory,i,j,k);
	DEBUG1 printf("create_file - file %s\n",str);

	fp = fopen(str,"w");

	while(size--) {
		fputc( 55,fp);
	}

	fclose(fp);
	DEBUG1 printf("create_file - done\n");
}

void
delete_file(char *directory)
{
int i,k,j;
FILE *fp;
char str[256];
int misses;

#define MISSMAX 4096

        DEBUG1 printf("delet_file(%s)\n",directory);
	misses = 0;
        do {
                i=RANGE(0,25);
                j=RANGE(0,25);
                k=RANGE(0,25);
		misses++;
        } while(files[i][j][k] != -1 && misses < MISSMAX);

	if(misses == MISSMAX) {
		misses = 0;
		for(i=0;i<26;i++)
		for(j=0;j<26;j++)
		for(k=0;k<26;k++) {
			if(files[i][j][k] == -1) {
				misses++;
				break;
			}
		}
	}
	if(misses == 0) /* there is no files left !!! */
		return;
        
        files[i][j][k] = 0;
        sprintf(str, "%s/%c/%c%c",directory,i,j,k);
	unlink(str);
	DEBUG1 printf("delete_file - done\n");
}

void hint(void)
{
        printf("Usage: nfile version %s\n",VERSION);
        printf("Hint: creates and deletes files = generates JFS log file work\n");
        printf("nfile -d directory [-k Kbytes] [-c Files] [-m MaxSeconds] [-z percent] [-o \"cmd\"]\n");
        printf("\t-d directory  - top level directory\n");
        printf("\t-k Kbytes     - size of the files to create in KB (default 4KB)\n");
        printf("\t-c Files      - number of files to maintain (+/- 10%) (default 4096)\n");
        printf("\t-f Files      - stop after this number of file changes\n");
        printf("\t-m MaxSeconds - stop of so many seconds\n");
        printf("\t-z percent    - percent of time to sleep/snooze\n");
        printf("\t-o \"cmd\"    - pretend to be a different cmd (must be the last option)\n");
        printf("Example:\n");
        printf("\tnfile -d mydir -k 1 -c 10000 -m 600 \n");
        printf("\tnfile -d /tmp/files -k 64 -o \"bert -x\" \n");
        exit(1);
}


int main(int argc, char **argv)
{
int i;
int j;
int k;
char *directory = 0;
int count = 0;
int limit = 1024*4;
int counting = 0;
int changes = 0;
int size = 1024*4;
int fudge;
int ch;
int seconds = 0;
int snooze = 0;
char command[256];
struct timeval start;
struct timeval now;
double diff;
double startsec;
double nowsec;
double hundredeth; /* 100ths of a second since we started */



        progname = argv[0];
        srandom(getpid());

        if(getenv("NSTRESS_DEBUG") != NULL) {
                debug = atoi(getenv("NSTRESS_DEBUG"));
                printf("debug level set to %d\n",debug);
        }

        while ((ch = getopt(argc, argv, "h?d:f:k:c:m:o:z:")) != -1)
        {
                switch(ch)
                {
                case '?':
                case 'h': hint();
                          break;
                case 'd': directory = optarg; break;
                case 'k': size = abs(atoi(optarg) * 1024); break;
                case 'c': limit = abs(atoi(optarg)); break;
                case 'f': changes = abs(atoi(optarg)); counting++; break;
                case 'm': seconds = abs(atoi(optarg)); break;
                case 'z': snooze = abs(atoi(optarg)); break;
                case 'o':       if(debug)
                                        printf("link(%s,%s)\n",progname,optarg);
                                SYSCALL(link(progname,optarg) );
                                switch(fork())
                                {
                                case -1: perror("fork failed"); break;
                                case 0: /* child */
                                        strcpy(command,optarg); /* save cmd */
                                        argv[0] = command;
                                        argv[optind-1] = 0; /* remove this option */
                                        argv[optind-2] = 0;
                                        argv[argc] = 0;
                                        if(debug) {
                                                printf("about to exec command \"%s\"\
n",command);
                                                for(i=0;i <argc; i++)
                                                        printf("argv[%d]=%s\n",i,argv
[i]);
                                        }
                                        SYSCALL( execv(command,argv) );
                                        break;
                                default: /* parent */
                                        break;
                                }
                                sleep(6); /* to allow other process to start before deleting the link */
                                SYSCALL( unlink(optarg) );
                                return 0;
                }
        }

	if(directory == 0)
		hint();
        if (snooze < 0 || snooze >99) {
                printf("nfile: percent not valid = %d (0 to 100)\n", snooze);
                exit(6);
        }

	printf("top directory=%s filelimit=%d filesize=%d ",directory,limit,size,seconds,snooze);
	if(seconds)	printf(" stop-after=%d secs",seconds);
	if(snooze) 	printf(" snooze-factor=%d",snooze);
	if(counting) 	printf(" stop after=%d file operations",changes);
	printf("\n");
	create_dirs(directory);
	read_filenames(directory);

	if(seconds > 0) {
		signal(SIGALRM,sighandler);
		alarm(seconds);
	}
	for(i=0;i<26;i++)
	for(j=0;j<26;j++)
	for(k=0;k<26;k++) {
		if(files[i][j][k] != 0 ) {
			DEBUG1 printf("files[%d/%c][%d/%c][%d/%c] = %d\n",i,i+'a',j,j+'a',k,k+'a',files[i][j][k]);
			count++;
		}
	}
	printf("Files in total at start = %d\n",count);



	while( ! interrupted) {

		fudge = limit + RANGE(0,(int)(limit*0.10));
		DEBUG2 printf("create phase count=%d, fudge=%d limit=%d\n",count,fudge,limit);
		for( ; count < fudge; count++) { 
			if(snooze > 0) {
				gettimeofday(&now, NULL);
				startsec = (double)start.tv_sec +
						((double)start.tv_usec/1000000.0);
				nowsec = (double)now.tv_sec +
						((double)now.tv_usec/1000000.0);
				diff = nowsec - startsec;

				/*printf("diff=%f\n",diff); */
				hundredeth = diff * 100.0;
				/*printf("100ths=%f\n",hundrede th); */
				if( hundredeth > 100 - snooze) {
					/*printf("usleep\n") */;
					usleep(snooze*10000);
					gettimeofday(&start, NULL);
				}
			}

			create_file(directory,size); 
			if(counting) {
				if(--changes <= 0) 
					exit(7);
			}
		}

		fudge = limit - RANGE(0,(int)(limit*0.10));
		DEBUG2 printf("delete phase count=%d, fudge=%d limit=%d\n",count,fudge,limit);
		for( ; count > fudge; count--) {
			if(snooze > 0) {
				gettimeofday(&now, NULL);
				startsec = (double)start.tv_sec +
						((double)start.tv_usec/1000000.0);
				nowsec = (double)now.tv_sec +
						((double)now.tv_usec/1000000.0);
				diff = nowsec - startsec;

				/*printf("diff=%f\n",diff); */
				hundredeth = diff * 100.0;
				/*printf("100ths=%f\n",hundrede th); */
				if( hundredeth > 100 - snooze) {
					/*printf("usleep\n") */;
					usleep(snooze*10000);
					gettimeofday(&start, NULL);
				}
			}

			delete_file(directory);
			if(counting) {
				if(--changes <= 0) 
					exit(8);
			}
		}

	}
	return 0;
}
