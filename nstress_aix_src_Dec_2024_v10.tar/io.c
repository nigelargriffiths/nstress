/* io.c part of nstress - a collect of programs to stress test a computer
 * io.o generally useful function
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/*	Buffer Functions					      	      */
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
void printb(char *buf,int size)
{
static char x[100] = "                                                                                "; 	/* string of 80 spaces */
char s[100];
int i;
int num = 0;
register char ch;

	strcpy(s,x);
	for(i=0;i < size;i++)
	{
		s[(num*3   )] = 
		     (ch = ((buf[i] >> 4) & 0x0f)) > 9 ? ch + 'a' -10: ch + '0';
		s[(num*3 +1)] = 
		     (ch = (buf[i] & 0x0f))        > 9 ? ch + 'a' -10: ch + '0';
		if(buf[i] < 0x7f && buf[i] >= ' ')
			s[num+60] = buf[i];
		else
			s[num+60] = '.';
		if( (i + 1) % 20 ==0)
		{
			printf("%s\n",s);
			strcpy(s,x);
			num = 0;
		}
		else num++;
	}
	if( num !=0)
		printf("%s\n",s);
}
	
int set_buf(char *buf)
{
char input[256];
int temp;
int i;
	printf("set buf: string or hex (s/h) >");
	gets(input);
	if(input[0] == 's')
	{
		printf("set buf: string >");
		gets(buf);
		return(strlen(buf));
	}
	else
	{
		printf("set buf: use q to quit\n");
		for(i=0; ;)
		{
			printf("set buf: hex %d >", i);
			gets(input);
			if(input[0] == 'q') 
				break;
			if(sscanf(input, "%x", &temp) == 1)
			{
				buf[i] = temp;
				i++;
			}
			else
			   printf("Invalid hex (q to quit)\n");
		}
		return(i);
	}
	return 0;
}

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/*	General Purpose Functions					      */
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

char getch(char *prompt)	/* get a character */
{
char input[256];

	printf("%s >",prompt);
	gets(input);
	return input[0];
}

int getb(char *prompt)	/* get yes or no */
{
char input[256];

    for(;;)
    {
	printf("%s (y/n)>",prompt);
	gets(input);
	if(input[0] == 'y' || input[0] == 'Y')
		return 1;
	if(input[0] == 'n' || input[0] == 'N')
		return 0;
	printf("Input y or n please\n");
    }
}

int geto(char *prompt)	/* get an octal number */
{
char input[256];
int i;

    for(;;)
    {
	printf("%s (octal) >",prompt);
	gets(input);
	if(sscanf(input,"%o", &i) == 1)
		return i;
	printf("Input an octal number please\n");
    }
}

int getx(char *prompt)	/* get a hexadecimal number */
{
char input[256];
int i;

    for(;;)
    {
	printf("%s (hex) >",prompt);
	gets(input);
	if(sscanf(input,"%x", &i) == 1)
		return i;
	printf("Input a hexadecimal number please\n");
    }
}

int geti(char *prompt)	/* get an integer */
{
char input[256];
int  i;

    for(;;)
    {
	printf("%s >",prompt);
	gets(input);
	if(sscanf(input,"%d", &i) == 1)
		return i;
	printf("Input a decimal number please\n");
    }
}
