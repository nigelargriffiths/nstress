/* semlib.c part of nstress - a collect of programs to stress test a computer
 * Shared memory library function part of IPC tests
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/shm.h>

char *strcpy();
char *strncpy();

char *memory_address = (char *)-1;
int   memory_id      = -1;

void memory_create(int key, int size)
{
key_t memkey;
int memory_flag;

        if(key == 0)
                memkey = IPC_PRIVATE;
        else
                memkey = key;

	memory_flag = 0666 | IPC_CREAT;

	if((memory_id = shmget(memkey,size,memory_flag)) == -1)
	{
		perror("shmget()");
		exit(1);
	}

	if((memory_address = (char *)shmat(memory_id,0,0)) == (char *)-1)
	{
		perror("shmat()");
		exit(2);
	}
}

void memory_write(char * str)
{
	(void)strcpy(memory_address, str);
}

void memory_read(char *str)
{
	(void)strcpy(str, memory_address);
}

void memory_delete(int report_error)
{
int ret = shmctl(memory_id,IPC_RMID,0) == -1;

	if(report_error && ret == -1)
	{
		perror("shmctl()");
		exit(2);
	}
}
