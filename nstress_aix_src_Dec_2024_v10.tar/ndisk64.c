/* ndisk64.c part of nstress - a collect of programs to stress test a computer
 * ndisk64 stresses your disks and file system caches with lots of I/O options.
 * (C) Copyright 2000 Nigel Griffiths
 * Additions and fixes Ralf Schmidt-Dannert

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#ifdef MIO
#include "MIO_user.h"

/* MIO is IBM's Modular I/O Library
 * Note that we define open64, lseek64, ftruncate64, and not the
 * open, lseek, and ftruncate that are used in the code.  This is
 * because MIO_user.h defines _LARGE_FILES which forces <fcntl.h> to
 * redefine open, lseek, and ftruncate as open64, lseek64, and
 * ftruncate64
 */

#define open64(a,b,c) MIO_open64(a,b,c,0)
#define close         MIO_close
#define lseek64       MIO_lseek64
#define write         MIO_write
#define read          MIO_read
#define ftruncate64   MIO_ftruncate64
#endif /* MIO */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/mman.h>
#include <sys/stat.h>
/* #include <macros.h> */
#include <sys/ipc.h>
#include <sys/shm.h>
/* #include <sys/wait.h> */

char *progname;


#include	<sys/aio.h>
#define AIOMAX 1024

/* switch on debug so its dynamic - see NSTRESS_DEBUG */
#define DEBUG 4

struct aiocb64 cb[AIOMAX];
volatile long aio_busy[AIOMAX];
volatile long aio_complete = 0;
volatile long aio_errors = 0;

#define RANGE(min,max) ((long)random() % ((long)(max) - (long)(min) +1L)) + (long)(min)

#define BLOCK_SIZE_LIST_MAX 32
#define MAXPROCS 1024*8

#define FILE_NAME_MAX 2048
#define MAPFILENAME	"tempfile_2MB"
#define MAPFILESIZE	2*1024*1024
#define NEWFILENAME	"tempfile"
#define MAXFILESIZE	4096 /* in MBytes */
#define MAXMEMSIZE	256 /* in MBytes */

#define SEQUENTIAL 1
#define RANDOM 2

#define FSYNCING 1
#define OSYNCING 2

#ifndef TRUE
#define TRUE 1
#endif 

#ifndef FALSE
#define FALSE 0
#endif 

long debug = 0;
long verbose = 0;
long logging = 0;
FILE *logfp;

#define __STRING(yyyy) "yyyy"
int errornum;

#define SYSCALL(xxxx) if((xxxx) == -1) { \
errornum=errno; \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:errno=%d\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", errornum,__FILE__, __FUNCTION__, __LINE__, __STRING(xxxx) ); \
shmptr[my_id].status = DONE;\
exit(42); \
} 

#define SYSCALL_FILENAME(xxxx) if((xxxx) == -1) { \
errornum=errno; \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:errno=%d\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", errornum,__FILE__, __FUNCTION__, __LINE__, __STRING(xxxx) ); \
fprintf(stderr,"Filename=\"%s\"\n", filename ); \
shmptr[my_id].status = DONE;\
exit(42); \
} 

#define NOTNULL(xxxx) if((xxxx) == NULL) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: NULL not returned:\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", __FILE__, __FUNCTION__, __LINE__, __STRING(xxxx) ); \
shmptr[my_id].status = DONE;\
exit(42); \
} 

#define DEBUG1(xxxx)  if(debug > 1) { fprintf(stderr,"\nDebug1: Function=%-20s, Line=%d \n", __FUNCTION__, __LINE__); xxxx } 
#define DEBUG2(xxxx)  if(debug > 2) { fprintf(stderr,"\nDebug2: Function=%-20s, Line=%d \n", __FUNCTION__, __LINE__); xxxx } 
#define DEBUG3(xxxx)  if(debug > 3) { fprintf(stderr,"\nDebug3: Function=%-20s, Line=%d \n", __FUNCTION__, __LINE__); xxxx } 

#define LOGNUM(name, p1,p2,p3)  lognumber((char *)name, (long long) p1,  (long long) p2, (long long) p3)

void lognumber(char *name, long long p1, long long p2, long long p3)
{ 
	if(logging) {
	if(logfp == 0) {
		char logname[128];
		sprintf(logname,"%d.log",getpid());
		logfp = fopen( logname, "w");
	}
	fprintf(logfp,"%s(%lld,%lld,%lld) (0x%llx,0x%llx,0x%llx) File=%s, Function=%s, Line=%d\n", name,(long long)p1,(long long)p2,(long long)p3,(long long)p1,(long long)p2,(long long)p3,__FILE__, __FUNCTION__, __LINE__  );
	} 
}



#define OLDLOGNUM(name,p1,p2,p3) \
if(logging) { \
if(logfp == 0) { \
		char logname[128]; \
		sprintf(logname,"%d.log",getpid()); \
		logfp = fopen( logname, "w"); \
} \
fprintf(logfp,"%s(%lld,%lld,%lld) (0x%llx,0x%llx,0x%llx) File=%s, Function=%s, Line=%d\n", name,(long long)p1,(long long)p2,(long long)p3,(long long)p1,(long long)p2,(long long)p3,__FILE__, __FUNCTION__, __LINE__  ); \
} 

#define LOGSTR(name,p1,p2,p3) \
if(logging) { \
if(logfp == 0) { \
		char logname[128]; \
		sprintf(logname,"%d.log",getpid()); \
		logfp = fopen( logname, "w"); \
} \
fprintf(logfp,"%s(%s,%s,%s) File=%s, Function=%s, Line=%d\n", name,p1,p2,p3,__FILE__, __FUNCTION__, __LINE__  ); \
} 

int randomise_1st_flag=0;
int randomise_all_flag=0;
int cio_flag=0;
int dio_flag=0;

/*Shared memory variable */
#define SHMKEY_PARALLEL	0xdeadbeef
#define SHMKEY_DATA	0xbeefdead
#define PERMS 0666
char *shm_address = 0;
key_t shm_user_key = (key_t)SHMKEY_DATA;
key_t shmid_parallel;
key_t shmid_data;
long shm_mb = 0;

unsigned long	not_interrupted;
unsigned long	iterations;
unsigned long	seconds = 5;

struct itimerval timerval_at_start;
struct itimerval timerval_at_end;
struct timeval starting;
struct timeval ending;
double	elapsed;

#define READ 1
#define WRITE 2

long go[100];

struct tdata {
	volatile long status;
	volatile long ios;
	volatile long reads;
	volatile long writes;
	volatile long rewinds;
	volatile double min;
	volatile double max;
	volatile double elapsed;
	volatile double iotime;
	volatile double synctime;
	char	pad [452];
	/* let's make tdata a 512 byte structure, so we have no false sharing
	** even at L3 cache with 512 byte line
	*/
};

#define TMAX
#define WAIT 1
#define RUN 2
#define STOP 3
#define DONE 4

long procs = 1;
volatile long my_id = 0;

volatile struct tdata *shmptr;

char *malloc_4k_aligned(unsigned long bs)
{
	char *mbuf;
	char *buf;
		NOTNULL( mbuf = malloc(bs + 4*1024) ); /* get extra 4K to allow alignment below */
		buf = (char *)(((long)mbuf +4*1024) &  0xFFFFF000); /* round to 4K boundary */
		if(debug) printf("Block size=0x%x malloc-size=0x%x malloc-buffer-address=0x%X aligned-4K-I/O-address=0x%X\n",bs,bs+4*1024,mbuf,buf);
	return buf;
}

void setup_go(long read_percent)
{
long set;
long def;
long i;
long place;
long count;
	DEBUG1( fprintf(stderr, "setup_go(read percent = %d)\n",read_percent); );
	if(read_percent < 50) {
		set = READ;
		def=  WRITE;
		count = read_percent;
	} else {
		set = WRITE;
		def=  READ;
		count = 100 - read_percent;
	}

	for(i=0;i<100;i++)
		go[i] = def;

	for(i = 0; i< count;i++) {
		do { 
			place = RANGE(0,99);
			LOGNUM( "go range(min,max) = x", 0, 99, place);
		} while( go[place] == set );
		go[place] = set;
	}
}

void
sig_handler(int signum)
{
	DEBUG1( fprintf(stderr, "sig_handler(signum= %d) 14=SIGALRM 23=SIGIO=SIGAIO\n",signum); );
	not_interrupted = FALSE;
	signal(SIGALRM, sig_handler);
}

void
start_countup_timer(void)
{
	/* Start a timer which won't expire before the item being timed
	 * completes.  50,000 seconds (over 13 hours) seems reasonable.
	 *
	 * Can't use the clock() function because (a) it includes the
	 * time for child processes and (b) it doesn't seem to include
	 * time spent in kernel mode.
	 */
	gettimeofday(&starting, NULL);
	timerval_at_start.it_value.tv_sec = 50000;
	timerval_at_start.it_value.tv_usec = 0;
	setitimer(0, &timerval_at_start, NULL);
}

void
stop_countup_timer_and_print(const char * message)
{
double elapsed_seconds;
	/* Alarm was never set - display how long elapsed before this
	 * function was called instead of printing out the number of
	 * iterations the loop went through.
	 */

	getitimer(0, &timerval_at_end);
	elapsed_seconds = timerval_at_start.it_value.tv_usec -
					timerval_at_end.it_value.tv_usec;
	elapsed_seconds /= CLOCKS_PER_SEC;
	elapsed_seconds += timerval_at_start.it_value.tv_sec -
					timerval_at_end.it_value.tv_sec ;
	printf("%-24s ", message);
	printf("   %5.2lf\n", elapsed_seconds);
}
void
start_timer(void)
{
	DEBUG3(printf("start_timer()\n"););
	gettimeofday(&starting, NULL);
	iterations = 0;
	not_interrupted = TRUE;
	if(procs > 1)
		return;
	signal(SIGALRM, sig_handler);
	alarm(seconds);
}

void
stop_timer_and_print(const char * message)
{
	gettimeofday(&ending,NULL);
	elapsed = (double)(ending.tv_sec - starting.tv_sec) + 
		  (double)((ending.tv_usec - starting.tv_usec))/1000000.0;
	printf("%-24s ", message);
	printf("  %12.2f ops/sec [%.1f seconds]\n", 
			iterations/elapsed, elapsed);
}

void
start_banner(const char * message)
{
	printf("*** Start %-20s ***\n", message);
}

void
end_banner(void)
{
}

/* DISK */
void
make_a_file(char *filename, long long file_size)
{
int fd;
long i;
char buf[1024*1024]; /* lets do 1MB chunks for speed */

	DEBUG1( fprintf(stderr,"called make_a_file(filename=%s,size=%;d)\n",filename,file_size); );

	printf("Creating file %s size=%lld (%lldKB or %lldMB)\n",
			filename,file_size, (long)(file_size/1024),
			(long)(file_size/1024/1024));
	LOGSTR("open64",filename,"O_RDWR|O_CREATE","0666");
    SYSCALL_FILENAME( fd = open64(filename, O_RDWR | O_CREAT, 0666) );

    for(i=0; i<file_size/sizeof(buf); i++) {
		LOGNUM("write",fd,buf,sizeof(buf));
		SYSCALL( write(fd, buf, sizeof(buf)) );
	}
	LOGNUM("close",fd,-9,-9);
    	SYSCALL( close(fd) );
	sync();
}

void
disk_setup_bigfile(char *filename, long long file_size)
{
	struct stat	statbuf;

	DEBUG1( fprintf(stderr,"called disk_setup_bigfile(filename=%s, size=%lld)\n",filename,file_size); );

	/* Find out the size of the file to make sure its big enough  */
	if( stat(filename, &statbuf) != -1 &&
	    statbuf.st_size >= file_size)
		return;

	unlink(filename); 
	make_a_file(filename,file_size);
}

void check_file_exists(char *filename)
{
int fd;
	fd = open64(filename, O_RDWR, 0);
	if(fd == -1) {
		printf("File \"%s\" open64() error=%d, does it exist? Do you have read AND write access?\n",filename,errno);
		perror("open64() error");
		exit(345);
	}
	close(fd);
}

/* MEMORY MAPPED FILE */
#define MAPPED_ARRAY_SIZE	500000

void
memory_mapped_file(void)
{
	int fd;
	char filename[64];
	long *	mptr;
	long	mapped_segment_size	= MAPPED_ARRAY_SIZE*sizeof(*mptr);

	DEBUG1( fprintf(stderr,"called disk_test_memory_mapped()\n"); );
	disk_setup_bigfile(MAPFILENAME, MAPFILESIZE);
	strcpy(filename,MAPFILENAME);
	SYSCALL_FILENAME(fd = open64(MAPFILENAME, O_RDWR, 0));
	mptr = (long *) mmap(0,
			mapped_segment_size,
			PROT_READ|PROT_WRITE, 
			MAP_SHARED,
			fd,
			0);

	if (mptr == (long *) -1) {
		perror("Could not map file");
	}
	else {
		start_timer();
		while (not_interrupted) {
			iterations++;
			mptr[0]++;
			mptr[MAPPED_ARRAY_SIZE - 1]++;

			SYSCALL( msync(mptr, mapped_segment_size, MS_SYNC) );
		}
		stop_timer_and_print("Mapped file 2MB sync's");
		SYSCALL( munmap(mptr, mapped_segment_size) );
	}
	SYSCALL( close(fd) );
}


void
file_creation(void)
{
	int fd;
	char *buf;
	char filename[64];

	DEBUG1( fprintf(stderr,"called file_creation()\n"); );

	NOTNULL( buf = malloc(4096) );
	unlink(NEWFILENAME);
	start_timer();
	strcpy(filename,NEWFILENAME);
	while (not_interrupted) {
		iterations++;
		SYSCALL_FILENAME(fd = open64(NEWFILENAME, O_RDWR | O_CREAT | O_EXCL,0666));
		SYSCALL( write(fd, buf, 4096) );
		SYSCALL( close(fd) );
		unlink(NEWFILENAME);
	}
	stop_timer_and_print("File create,write,close,unlink");
	free(buf);
}

void
sync_rdbms_test(long iotype, 
	char * filename, 
	long long file_size, 
	long read_percent, 
	unsigned long bs, 
	long fsyncing,
	long snooze, 
	off64_t offset)
{
	int		fd;
	unsigned long blocknum = 0;
	unsigned long blocks;
	struct stat64 	statbuf;
	char 		*buf;
	char 		*mbuf;
	double 		elapse = 0.0;
	double 		iotime = 0.0;
	struct timeval	startop;
	struct timeval	endop;
	double 	min = 999999.9;
	double 	max = 0.0;
	long	reads = 0;
	long	writes = 0;
	long 	rewinds = 0;

        struct timeval start;
        struct timeval now;
        double diff;
        double startsec;
        double nowsec;
        double hundredeth; /* 100ths of a second since we started */
        long open_flags;
        char open_str[64];
	double microseconds = 0.0; /* time spent asleep */
	long count;

	DEBUG1(fprintf(stderr,"rdbms_test(iotype=%d,filename=%s,file_size=%lld,read_percent=%d,bs=%ld,fsync=%d)\n",iotype,filename,file_size,read_percent,bs,fsyncing););

	setup_go(read_percent);

	/* Allocate buffer used for disk transfers. */
	if(shm_address == 0){
		buf = malloc_4k_aligned(bs);
	}
	else buf = shm_address;
printf("start randomise - bs=%ld sizeof(long)=%ld\n",(long)(bs),(long)sizeof(long));
	if(randomise_1st_flag || randomise_all_flag) {
		for(count=0; count < (bs/sizeof(long)); count++) {
			((long *)buf)[count] = (long)random();
printf("%ld ",count);
		}
	}
printf("stop  randomise\n");

	open_flags = O_RDWR;
	strcpy(&open_str[0],"O_RDWR");

	if(fsyncing == OSYNCING){
		open_flags = open_flags | O_SYNC;
		strcat(open_str,"|O_SYNC");
	}
	if(cio_flag){
		open_flags = open_flags | O_CIO;
		strcat(open_str,"|O_CIO");
	}
	if(dio_flag){
		open_flags = open_flags | O_DIRECT;
		strcat(open_str,"|O_DIRECT");
	}
        LOGSTR( "open64" ,filename, open_str, "0" );
        SYSCALL_FILENAME( fd = open64(filename, open_flags, 0) );

	if (file_size == 0) {
		printf("Determining the size of file:%s\n", filename);
		LOGNUM("fstat64",fd,-9,-9);
		SYSCALL( fstat64(fd, &statbuf) );
		file_size = statbuf.st_size;
		printf("File %s size %lld bytes\n", filename, file_size);
		if(statbuf.st_size == 0) {
			printf("File %s is zero bytes long - aborting this I/O thread\n", filename);
			return;
		}
	}
	blocks = file_size / bs;
	LOGNUM("blocks",blocks,-9,-9);
	if(offset > (off64_t)0) {
		/* Dont do I/O beyond the last block */
		if( offset > file_size - bs )
			offset = (blocks - 1) * bs;
#ifdef LSEEK_TEST
		printf("lseek64 %lld\n",(long long)offset); 
		offset = 0;
#endif
		LOGNUM( "offset lseek64",fd, offset, SEEK_SET );
		SYSCALL( lseek64(fd, offset, SEEK_SET) );

		blocknum = offset / (off64_t) bs;
       }
	if(!debug)while( shmptr[my_id].status == WAIT)
		usleep(10);

	gettimeofday(&start, NULL);
	gettimeofday(&starting, NULL);
	iterations = 0;

	while ( shmptr[my_id].status == RUN ) {
		iterations++;
		if(randomise_all_flag) {
			((long *)buf)[0] = (long)random();
		}

		if(verbose) 
			gettimeofday(&startop,NULL);
		if(iotype == RANDOM) {
			/* Ensure that the highest blocknum returned is at minimum 
			 * one block less than the file size so we can write or 
			 * read one full block from that location.
			 */
			blocknum = RANGE(0,blocks-1);
			LOGNUM( "range(min,max) = x", 0, blocks-1, blocknum);
			LOGNUM( "lseek64",fd, (off64_t)blocknum * (off64_t)bs, SEEK_SET );
#ifdef LSEEK_TEST
			printf("lseek64 %lld\n",(long long)((off64_t)blocknum * (off64_t)bs)); 
			SYSCALL( lseek64(fd, (off64_t)0, SEEK_SET) );
#else
			SYSCALL( lseek64(fd, (off64_t)blocknum * (off64_t)bs, SEEK_SET) );
#endif
		} else { /* SEQUENTIAL */
			blocknum++;
			if( blocknum >= blocks) {
				blocknum = 0;
				LOGNUM( "lseek64",fd, 0, SEEK_SET );
				SYSCALL( lseek64(fd, 0L, SEEK_SET) );
				rewinds++;
			}
		}
		if(read_percent == 100 || go[iterations % 100] == READ) {
			reads++;
			LOGNUM( "read",fd, buf, bs );
			SYSCALL( read(fd, buf, bs) );
		}
		else {
			writes++;
			LOGNUM( "write",fd, buf, bs );
			SYSCALL( write(fd, buf, bs) );
			if(fsyncing == FSYNCING) {
				LOGNUM( "fsync",fd, -9, -9 );
				SYSCALL(fsync(fd));
			}
		}

		if(verbose) {
			gettimeofday(&endop,NULL);
			elapse = (double)(endop.tv_sec - startop.tv_sec) + 
			  (double)((endop.tv_usec - startop.tv_usec))/1000000.0;
			if( elapse < min)
				min = elapse;
			if(elapse > max)
				max = elapse;
			iotime += elapse;
		}
		if(snooze > 0) {
			gettimeofday(&now, NULL);
			startsec = (double)start.tv_sec +
				  ((double)start.tv_usec/1000000.0);
			nowsec = (double)now.tv_sec +
				((double)now.tv_usec/1000000.0);
			diff = nowsec - startsec;

			/*printf("diff=%f\n",diff); */
			hundredeth = diff * 100.0;
			/*printf("100ths=%f\n",hundrede th); */
			if( hundredeth > 100 - snooze) {
				/*printf("usleep\n") */;
				usleep(snooze*10000);
				microseconds = microseconds + snooze*10000;
				gettimeofday(&start, NULL);
			}
		}
	}

	gettimeofday(&ending,NULL);
	elapsed = (double)(ending.tv_sec - starting.tv_sec) + 
	  (double)((ending.tv_usec - starting.tv_usec))/1000000.0;

	if(snooze > 0) {
		elapsed = elapsed - (microseconds/1000000.0);
	}
	gettimeofday(&now, NULL);
	
	shmptr[my_id].ios = iterations;
	shmptr[my_id].min = min;
	shmptr[my_id].max = max;
	shmptr[my_id].reads = reads;
	shmptr[my_id].writes = writes;
	shmptr[my_id].rewinds = rewinds;
	shmptr[my_id].elapsed = elapsed;
	shmptr[my_id].iotime = iotime;

	if(verbose && read_percent != 100) { /* we need to sync(); the data to disk */
		gettimeofday(&starting, NULL);
		LOGNUM( "fsync",fd, -9, -9 );
		/* SYSCALL(fsync(fd)); */
		fsync(fd);	/* ignore fsync() errors here as a raw device will return an error */
		LOGNUM( "close",fd, -9, -9 );
		SYSCALL(close(fd));
		gettimeofday(&ending,NULL);
		elapsed = (double)(ending.tv_sec - starting.tv_sec) + 
		  (double)((ending.tv_usec - starting.tv_usec))/1000000.0;
		shmptr[my_id].synctime = elapsed;
	}
	free(mbuf);
	shmptr[my_id].status = DONE;
}

static int cancelfd;

void cancel_outstanding(void)
{
	int	count = 0;
	int	i;
	int	rc = 0;

	for(i=0;i<AIOMAX;i++)
		if(aio_busy[i] == 1)
		{
			count++;
			LOGNUM( "aio_cancel",cancelfd,NULL,-9 );
			aio_cancel64(cancelfd,&cb[i]);
			rc=aio_error64(&cb[i]);
			DEBUG1(printf("Cancel cb %d, rc = %d\n",i,rc););
			aio_busy[i]=0;
		}

	if(count>0)
	{
		if(verbose) printf("Cancelling outstanding AIOs %d\n",count);
	}
}

long outstanding()
{
long i;
long inprogress = 0;
long error = 0;
	for(i=0;i<AIOMAX;i++) { 	/* search all control blocks */
		if(aio_busy[i] == 1) 	/* if in use */
				inprogress++;
	}
	if (inprogress > 0 && shmptr[my_id].status==STOP)
	{
		DEBUG1(printf("my_id=%d, outstanding returning %d\n",my_id,inprogress););
		cancel_outstanding();
	}
	return inprogress;
}

void aio_signal(int sig)
{
	long i;
	long error;
	long inprogress = 0;

	signal(SIGIO, aio_signal); /* reset signal */
	if(debug> 0) fprintf(stderr,"\ncalled aio_signal(%d) 23=SIGAIO=SIGIO\n",sig);

	for(i=0;i<AIOMAX;i++) { 	/* search all control blocks */
		if(aio_busy[i] == 1) { 	/* if in use */
			error = aio_error64(&cb[i]);
			if(error  == EINPROGRESS) {
				inprogress++; 	/* I/O not yet completed - so skip*/
			} else {
					/* complete - so check the results */
				if(error == -1) {
					aio_errors++;
					if(debug> 0) {
						fprintf(stderr,"\taio_signal aio_return=%d aio_error=%d\n",
								cb[i].aio_return,
								cb[i].aio_errno);
					}
				} else {
					aio_complete++;
				}
				aio_busy[i] = 0;
			}
		}
	}
	if(debug> 0) {
		fprintf(stderr,"\taio_signal inprogress=%d error=%d complete=%d\n",
				inprogress,aio_errors,aio_complete);
	}
}

void
aio_rdbms_test(long iotype, 
	char * filename, 
	long long file_size, 
	long read_percent, 
	long amin , 
	long amax, 
	unsigned long block_size, 
	long fsyncing, 
	off64_t offset)
{
	int		fd;
	unsigned long	rewinds = 0;
	unsigned long	reads = 0;
	unsigned long	writes = 0;
	unsigned long	total = 0;
	unsigned long	out;
	unsigned long	i;
	unsigned long	j;
	unsigned long   count;
	unsigned long block = 1;
	unsigned long blocks;
	char		error_msg[127+1];
	struct stat64	statbuf;
	long open_flags;
	char open_str[64];

	DEBUG1(
		fprintf(stderr,"called aio_rdbms_test(iotype=%d, filename=%s,filesize=%lld,read_percent=%d amin=%d amax=%d block_size=%ld fsyncing=%s)\n",
			iotype, filename, file_size, read_percent, amin, amax, block_size, 
			(fsyncing == FSYNCING)?"fsync()": 
				((fsyncing == OSYNCING)?"O_SYNC":"No")); );
	
	setup_go(read_percent);

	open_flags = O_RDWR;
	strcpy(&open_str[0],"O_RDWR");

	if(fsyncing == OSYNCING){
		open_flags = open_flags | O_SYNC;
		strcat(open_str,"|O_SYNC");
	}
	if(cio_flag){
		open_flags = open_flags | O_CIO;
		strcat(open_str,"|O_CIO");
	}
	if(dio_flag){
		open_flags = open_flags | O_DIRECT;
		strcat(open_str,"|O_DIRECT");
	}
	LOGSTR( "open64" ,filename, open_str, "0" );
	SYSCALL_FILENAME( fd = open64(filename, open_flags, 0) );

	if (file_size == 0) {
		printf("Determining the size of file:%s\n", filename);
		LOGSTR( "fstat64" ,filename, "", "" );
		SYSCALL( fstat64(fd, &statbuf) );
		file_size = statbuf.st_size;
		printf("File %s size %lld bytes\n", filename, file_size);
		if(statbuf.st_size == 0) {
			printf("File %s is zero bytes long - aborting this I/O thread\n", filename);
			return;
		}
	}
	blocks = file_size / (long long)block_size;
	blocks--; /* remove the last block - in case its not a whole block */
	LOGNUM("blocks",blocks,-9,-9);
	/* what about if filesize is less than 1 block ? */

#ifdef DEBUG
	DEBUG1(printf("\nAsync I/O %s sytle\nfile=%s blocks=%ld read/write-ratio=%d%% blocksize=%d AIO requests amin=%d amax=%d\n", (iotype == SEQUENTIAL)? "Sequential": "Random", filename,blocks,read_percent,block_size,amin,amax); );
#endif

	LOGNUM("usleep status",shmptr[my_id].status, my_id,-9);
        while( shmptr[my_id].status == WAIT)
                usleep(100);

        gettimeofday(&starting, NULL);
        iterations = 0;

        if(offset > (off64_t)0) {
		/* Dont do I/O beyond the last block */
		if( offset > file_size - block_size )
			block = blocks-1;
		else
			block = offset / (off64_t)block_size;
        }

	LOGNUM(" while status",shmptr[my_id].status, my_id,amax);
	signal(SIGIO, aio_signal);

	DEBUG1(fprintf(stderr,"ENTERING WHILE LOOP\n");)
	while (shmptr[my_id].status == RUN) {
	    for(count=outstanding();count<amax;count++){
		iterations++;

		/* find empty control block */
		for(i=0;i<AIOMAX;i++)
			if(aio_busy[i] == 0)
				break;

		LOGNUM( "aio slot", i, -9, -9);
		if(iotype == SEQUENTIAL) {
			if(++block >= blocks) {
				block = 0;
				rewinds++;
			}
		}
		else {	/* RANDOM */
			/* Ensure that the highest blocknum returned is at minimum 
			 * one block less than the file size so we can write or 
			 * read one full block from that location.
			 */
			block = RANGE(0,blocks-1);/* randomly decide which block to read */
            LOGNUM( "range(min,max) = x", 0, blocks, block);
		}
		if(block > blocks-1 )  /* just a sanity check */
			block = 0;
		cb[i].aio_fildes = fd;
		cb[i].aio_offset = (off64_t)block * (off64_t)block_size;
						/* this will lseek to the right byte */
		if(cb[i].aio_buf == 0) {	/* if we have no buffer grab one now */
		    	if(shm_address == 0) {
				cb[i].aio_buf = malloc_4k_aligned(block_size);
		    	}
		    	else 
				cb[i].aio_buf = shm_address + block_size*i;
		}
		cb[i].aio_nbytes = block_size;	/* read/write size */

		/* cb[i].aio_sigevent.sigev_value.sival_int = 0; */
		cb[i].aio_sigevent.sigev_signo = SIGIO;
		cb[i].aio_sigevent.sigev_notify = SIGEV_SIGNAL;
		cb[i].aio_sigevent.sigev_notify_function = (void(*)(union sigval))aio_signal;
		/* cb[i].aio_sigevent.sigev_notify_attributes = 0; */
		cb[i].aio_errno = 0;	 	/* zero so we can check for errors */
		aio_busy[i] = 1;

#ifdef DEBUG
	if(debug > 3) {
		fprintf(stderr,"aio control block[%d],offset=%lld,buf=0x%x,nbytes=%d\n", i, 
                cb[i].aio_offset,
                cb[i].aio_buf,
                cb[i].aio_nbytes);
	}
#endif /* DEBUG */

		if ( read_percent == 100 || go[iterations % 100] == READ) {
			reads++;
			LOGNUM( "aio_read64", fd, &cb[i], i );
			SYSCALL( aio_read64(&cb[i]) );
#ifdef DEBUG
			if(debug > 3) fprintf(stderr,"aio_read at block %d\n", block);
#endif /* DEBUG */
		}
		else {
			writes++;
			LOGNUM( "aio_write64", fd,&cb[i],i );
			SYSCALL( aio_write64(&cb[i]) );
#ifdef DEBUG
			if(debug > 3) fprintf(stderr,"aio_write at block %d\n", block);
#endif /* DEBUG */
		}
	    }

	    while((out = outstanding()) > amin) {
                /* usleep(100); */
		signal(SIGALRM, sig_handler);
		alarm(2);
		LOGNUM( "pause", outstanding(),amin,amax );
		signal(SIGIO, aio_signal); 
		pause(); 	/* wait till I/O signal handling completes */
		
		if(fsyncing == FSYNCING)
		    SYSCALL(fsync(fd))
	    }
	}
	DEBUG1(fprintf(stderr,"END OF LOOP\n");)
	/*alarm(0);*/
        gettimeofday(&ending,NULL);
        elapsed = (double)(ending.tv_sec - starting.tv_sec) +
          (double)((ending.tv_usec - starting.tv_usec))/1000000.0;
        shmptr[my_id].ios = iterations;
	DEBUG1(fprintf(stderr,"my_id=%d, ios=%d\n",my_id,iterations););
        shmptr[my_id].reads = reads;
        shmptr[my_id].writes = writes;
        shmptr[my_id].rewinds = rewinds;
        shmptr[my_id].elapsed = elapsed;


	cancelfd = fd;
	cancel_outstanding();
        if(verbose && read_percent != 100) { /* we need to sync(); the data to disk */
                gettimeofday(&starting, NULL);
                LOGNUM( "fsync",fd, -9, -9 );
		/* SYSCALL(fsync(fd)); */
		fsync(fd);	/* ignore fsync() errors here as a raw device will return an error */
                LOGNUM( "close",fd, -9, -9 );
                SYSCALL(close(fd));
                gettimeofday(&ending,NULL);
                elapsed = (double)(ending.tv_sec - starting.tv_sec) +
                  (double)((ending.tv_usec - starting.tv_usec))/1000000.0;
                shmptr[my_id].synctime = elapsed;
        }
        else {
                SYSCALL(close(fd));
        }

	if(aio_errors) printf("AIO errors=%d\n",aio_errors);
        shmptr[my_id].status = DONE;
}

void
hint(void)
{
	fprintf(stderr, "\nUsage: %s version %s\n\
Complex Disk tests - sequential or random read and write mixture\n\
%7s -S          Sequential Disk I/O test (file or raw device)\n\
        -R          Random    Disk I/O test (file or raw device)\n\n\
        -t <secs>   Timed duration of the test in seconds (default 5)\n\n\
        -f <file>   use \"File\" for disk I/O (can be a file or raw device)\n\
        -f <list>   list of filenames to use (max 16) [separators :,+]\n\
     			example: -f f1,f2,f3  or -f /dev/rlv1:/dev/rlv2\n\
        -F <file>   <file> contains list of filenames, one per line (upto %d files)\n\
        -M <num>    Multiple processes used to generate I/O\n\
        -s <size>   file Size, use with K, M or G (mandatory for raw device)\n\
			examples: -s 1024K   or   -s 256M   or   -s 4G\n\
			The default is 32MB\n\
        -r <read%%> Read percent min=0,max=100 (default 80 =80%%read+20%%write)\n\
			example -r 50 (-r 0 = write only, -r 100 = read only)\n\
        -b <size>   Block size, use with K, M or G (default 4KB) \n\
        -O <size>   first byte offset use with K, M or G (times by proc#)\n\
        -b <list>   or use a colon separated list of block sizes (%d max sizes)\n\
			example -b 512:1k:2K:8k:1M:2m\n\
        -q          flush file to disk after each write (fsync())\n\
        -Q          flush file to disk via open() O_SYNC flag\n\
        -i <MB>     Use shared memory for I/O MB is the size(max=%d MB)\n\
        -v          Verbose mode = gives extra stats but slower\n\
        -l          Logging disk I/O mode = see *.log but slower still\n\
        -o \"cmd\"  Other command - pretend to be this other cmd when running\n\
                        Must be the last option on the line\n\
        -K num      Shared memory key (default 0xdeadbeef) allows multiple programs\n\
        	    Note: if you kill ndisk,  you may have a shared memory\n\
		    segment left over. Use ipcs and then ipcrm to remove it.\n\
        -p          Pure = each Sequential thread does read or write not both\n\
        -P file     Pure with separate file for writers\n\
        -C          Open files in Concurrent I/O mode O_CIO\n\
        -D          Open files in Direct I/O mode O_DIRECT\n\
        -w          Randomise write buffer content as the start (all bytes)\n\
        -W          Randomise write buffer content always (just a few bytes different)\n\
        -z percent  Snooze percent - time spent sleeping (default 0)\n\
        		 Note: ignored for Async mode\n\
To make a file use dd, for 8 GB: dd if=/dev/zero of=myfile bs=1M count=8196\n",
	progname,
	VERSION,
	progname,
	FILE_NAME_MAX-1,
	BLOCK_SIZE_LIST_MAX-1,
	MAXMEMSIZE);

	fprintf(stderr, "\nAsynchronous I/O tests (AIO)\n\
        -A         switch on Async I/O use: -S/-R, -f/-F and -r, -M, -s, -b, -C, -D to determine I/O types\n\
		(JFS file or raw device)\n\
        -x <min>   minimum outstanding Async I/Os (default=1, min=1 and min<max)\n\
        -X <max>   maximum outstanding Async I/Os (default=8, max=%d)\n\
        see above -f <file>  -s <size>   -R <read%%>  -b <size>\n",AIOMAX);

	fprintf(stderr, "\nFor example:\n\
	dd if=/dev/zero of=bigfile bs=1m count=1024\n\
	%7s -f bigfile -S -r100 -b 4096:8k:64k:1m -t 600\n\
	%7s -f bigfile -R -r75 -b 4096:8k:64k:1m -q\n\
	%7s -F filelist -R -r75 -b 4096:8k:64k:1m -M 16\n\
	%7s -F filelist -R -r75 -b 4096:8k:64k:1m -M 16 -l -v\n",
	progname,
	progname,
	progname,
	progname
	);
	fprintf(stderr, "\nFor example:\n\
	%7s for Asynch compiled in version\n\
	%7s -A -F filelist -R -r50 -b 4096:8k:64k:1m -M 16 -x 8 -X 64\n",
	progname,
	progname
	);
}


int
main(int argc, char** argv)
{
	FILE *fpr;
	FILE *fpw;
	long attached = 0;
	long fsyncing = 0;
	long block_size_list[BLOCK_SIZE_LIST_MAX];
	long block_size_max = 0;

	char *filename_list[FILE_NAME_MAX];
	char *pfilename_list[FILE_NAME_MAX];
	long filename_max = 0;
	long pfilename_max = 0;

	char *str;
	long i;
	long t;
	long bs = 4096;
	char pfilename[1024] = {0};
	char filename[1024] = {0};
	long mb = 32;
	off64_t offset = 0;
	int ch;
	long need_usage_message = FALSE;
	long do_disk = FALSE;
	long do_rdbms = FALSE;
	long iotype = SEQUENTIAL;
	long do_async = FALSE;
	long purish = FALSE;
	long pure = FALSE;
	long pure_read;
	double pure_readf;
	long pure_write;
	long quiet = FALSE;
	long long file_size = 0;
	long aio_min = -1;
	long aio_max = -1;
	long read_percent = 80; /* default  of typical database */
	long actual_percent = 0; 
	double total;
	long total_ios;
	double total_iospersec;
	double total_mbpersec;
	double total_kbpersec;

	int pid;
	int status;
	long shm_size;
	char *qtmp;
	char *vtmp;
	char command[256];
	long snooze = 0;

	if(getenv("NSTRESS_DEBUG") != NULL) {
		debug = atoi(getenv("NSTRESS_DEBUG"));
		printf("debug level set to %d\n",debug);
	}

	/* set up defaults that the user can override */
	block_size_list[0] = 4096;
	block_size_max = 1;
	if(getenv("NSTRESS_RANDOM") != NULL) 
		srandom(atoi(getenv("NSTRESS_RANDOM")));
	else
		srandom(getpid());

	progname = argv[0];

	while ((ch = getopt(argc, argv, "Ab:dCDSRf:F:s:M:t:r:u:x:X:pP:qQlvkK:o:O:i:z:?hwW")) != -1)
	{
		switch(ch)
		{
               case 'w':       randomise_1st_flag=1;
                               break;
               case 'W':       randomise_all_flag=1;
                               break;
               case 'C':       cio_flag=1;
                               break;
               case 'D':       dio_flag=1;
                               break;
               case 'O':       offset = atoll(optarg);
                               if(tolower(optarg[strlen(optarg)-1]) == 'k')
                                       offset *= 1024;
                               if(tolower(optarg[strlen(optarg)-1]) == 'm')
                                       offset *= 1024 * 1024;
                               if(tolower(optarg[strlen(optarg)-1]) == 'g')
                                       offset *= 1024 * 1024 * 1024;
                               break;
 

		case 'o':	if(debug) 
					printf("link(%s,%s)\n",progname,optarg);
				SYSCALL(link(progname,optarg) );
				switch(fork())
				{
				case -1: perror("fork failed"); break;
				case 0: /* child */
					strcpy(command,optarg); /* save cmd */
					argv[0] = command;
					argv[optind-1] = 0; /* remove this option */
					argv[optind-2] = 0; 
					argv[argc] = 0;
					if(debug) {
						printf("about to exec command \"%s\"\n",command);
						for(i=0;i <argc; i++)
							printf("argv[%d]=%s\n",i,argv[i]);
					}
					SYSCALL( execv(command,argv) );
					break;
				default: /* parent */
					break;
				}
				sleep(6); /* to allow other process to start before deleting the link */
				SYSCALL( unlink(optarg) );
				return 0;

		case 'h':	/* drop through */
		case '?':	hint();
				return 0;
		case 'b':	
				str = optarg;
				for(i=0;i<BLOCK_SIZE_LIST_MAX;i++) {
					block_size_list[i] = 4096;
					if( sscanf(str, "%ld", &block_size_list[i]) != 1)
						break;
					while(isdigit(str[0]) && str[0] != 0)
						str++;
					if(tolower(str[0]) == 'k')
						block_size_list[i] *= 1024;
					if(tolower(str[0]) == 'm')
						block_size_list[i] *= 1024 * 1024;
					while(!isdigit(str[0]) && str[0] != 0)
						str++;
				}
				block_size_max = i;
				break;

/* AIO */
		case 'A':	do_async = TRUE; break;
		case 'x':	aio_min = atoi(optarg); break;
		case 'X':	aio_max = atoi(optarg); break;

		case 'k':	quiet = TRUE; break;
		case 'K':	shm_user_key = (key_t)atol(optarg); break;

		case 'd':	do_disk = TRUE; break;
		case 'v':	verbose = TRUE; break;
		case 'l':	logging = TRUE; break;

		case 'S':	do_rdbms = TRUE; 
				iotype = SEQUENTIAL;
				break;
		case 'R':	do_rdbms = TRUE; 
				iotype = RANDOM;    
				break;
		case 'p':	purish = TRUE; 
				break;
		case 'P':	pure = TRUE; 
				purish = FALSE;
				printf("\tReading file of filenames for write \"%s\" \n",optarg);
				if((fpw = fopen(optarg,"r")) == NULL) {
					perror(optarg);
					exit(42);
				}
				pfilename_max = 0;
				while( fgets(pfilename,1024, fpw) != NULL) {
					if(pfilename[strlen(pfilename)-1] == '\n') /* ditch NL's */
						pfilename[strlen(pfilename)-1] = 0;
					pfilename_list[pfilename_max] = malloc(strlen(pfilename)+1);
					strcpy(pfilename_list[pfilename_max], pfilename);

					check_file_exists(pfilename_list[pfilename_max]);
					pfilename_max++;
					if(pfilename_max > FILE_NAME_MAX)
						break;
				}
				fclose(fpw);
				break;

		case 'f':	/* Take upto 16 filenames from the command line
				  separated by one of : ; + , chars */
				for(i=0;i<16;i++) {
					filename_list[i] = malloc(1024);
					filename_list[i][0] = 0;
				}
				for(i=0;i<strlen(optarg);i++)
					if(optarg[i] == ':' || 
					   optarg[i] == ',' || 
					   optarg[i] == '+')
						optarg[i] = ' ';

				filename_max = sscanf( optarg,
					"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ", 
					filename_list[0],
					filename_list[1],
					filename_list[2],
					filename_list[3],
					filename_list[4],
					filename_list[5],
					filename_list[6],
					filename_list[7],
					filename_list[8],
					filename_list[9],
					filename_list[10],
					filename_list[11],
					filename_list[12],
					filename_list[13],
					filename_list[14],
					filename_list[15]
					);
				for(i=0;i<16;i++) {
					if(filename_list[i][0] != 0)
					check_file_exists(filename_list[i]);
				}
				break;

		case 'F':	
				printf("\tReading file of filenames \"%s\" \n",optarg);
				if((fpr = fopen(optarg,"r")) == NULL) {
					perror(optarg);
					exit(42);
				}
				filename_max = 0;
				while( fgets(filename,1024, fpr) != NULL) {
					if(filename[strlen(filename)-1] == '\n') /* ditch NL's */
						filename[strlen(filename)-1] = 0;
					if(filename[strlen(filename)-1] == ' ') /* ditch space's */
						filename[strlen(filename)-1] = 0;
					filename_list[filename_max] = malloc(strlen(filename)+1);
					strcpy(filename_list[filename_max], filename);

/* printf("got X%sX\n",filename_list[filename_max]); */
					check_file_exists(filename_list[filename_max]);
					filename_max++;
					if(filename_max > FILE_NAME_MAX)
						break;
				}
				fclose(fpr);
				if(filename_list[filename_max-1][strlen(filename_list[filename_max-1])-1] == ' ') /* ditch space's */
					filename_list[filename_max-1][strlen(filename_list[filename_max-1])-1] = 0;
				break;

		case 's': 	file_size = (long long)atoll(optarg);
				if(tolower(optarg[strlen(optarg)-1]) == 'k')
					file_size *= (long long)1024;
				if(tolower(optarg[strlen(optarg)-1]) == 'm')
					file_size *= (long long)1024 * 1024;
				if(tolower(optarg[strlen(optarg)-1]) == 'g')
					file_size *= (long long)1024 * 1024 * 1024;
					break;

		case 'r': 	read_percent  = atoi(optarg);
				if( read_percent < 0 || read_percent >100) {
					printf("ERROR: -r read%% is invalid, must be between 0 and 100 (inclusive).\n");
					exit(42);
				}
				break;

		case 'M':	procs = atoi(optarg);
				if(procs<1 || procs > MAXPROCS) {
					printf("ERROR: -M option %d is invalid, it should be between 1 and %d.\n",procs,MAXPROCS);
					exit(43);
				}
				break;

		case 'q': 	fsyncing = FSYNCING; 
				break;

		case 'Q': 	fsyncing = OSYNCING; 
				break;

		case 't':	seconds = atoi(optarg); 
				break;

		case 'i':	shm_mb = atoi(optarg);
				if( shm_mb <= 0  || shm_mb > MAXMEMSIZE) {
					printf("-i MB is invalid, must be greater than 0 and less than %d\n",MAXMEMSIZE);
					exit(43);
				}
				SYSCALL( shmid_data = 
						shmget(SHMKEY_PARALLEL, 
						shm_mb *1024 *1024 + 4 * 1024, 
						IPC_CREAT | SHM_R | SHM_W | IPC_EXCL) );
				SYSCALL( (int)(shm_address = 
					(char *)shmat(shmid_data,(void *)0,0)) );
				shm_address = (char *)(((long)shm_address +4*1024) &  0xFFFFF000); /* round to 4K boundary */
				printf("Shared memory attached at address 0x%lx\n",shm_address);
				break;
		case 'z':	snooze = atoi(optarg); 
				break;

		}
	}

	if(!quiet) {
		printf("Command: ");

		for(i=0;i<argc;i++)
			printf("%s ",argv[i]);
		printf("\n");
	}

	/* Print out the usage message if (a) an unknown flag was used on the
	 * command line, (b) there were no arguments or (c) there were arguments
	 * which were not flags like -p or whatever.
	 */
	if (need_usage_message || argc == 1 || optind < argc) {
		hint();
		exit(2);
	}
	/* Check Async I/O options */
	if(do_async == FALSE && aio_min != -1) {
		printf("-x option only applies to Async I/O, so either add -A or remove this option\n");
		hint();
		exit(45);
	}
	if(do_async == FALSE && aio_max != -1) {
		printf("-X option only applies to Async I/O, so either add -A or remove this option\n");
		hint();
		exit(46);
	}
	if(do_async == TRUE) {
		if(aio_min<0) aio_min = 1;
		if(aio_max<0) aio_max = 8;
		if(aio_max>1023) aio_max = 1023;
		if(aio_min>aio_max) {
			aio_min=1;
			aio_max=8;
		}
	}
	if((do_rdbms == TRUE || do_disk == TRUE) && filename_list[0] == 0) { /* i.e. unset */
		printf("No filename supplied. Use -f or -F to supply filename(s)\n");
		exit(46);
	}
	if (do_disk == TRUE) {
		if(fsyncing == FSYNCING)
			qtmp = "-q";
		else if(fsyncing == OSYNCING)
			qtmp = "-Q";
		else
			qtmp = "";
		if(verbose)
			vtmp = "-v";
		else
			vtmp = "";
		for(i=0;i<block_size_max;i++) {
		sprintf(command,"%s -S -r100 -f %s -M%d -b %d %s %s -k",progname,filename_list[0],procs,block_size_list[i],qtmp,vtmp);
			system(command);
		sprintf(command,"%s -S -r0   -f %s -M%d -b %d %s %s -k",progname,filename_list[0],procs,block_size_list[i],qtmp,vtmp);
			system(command);
		sprintf(command,"%s -R -r50  -f %s -M%d -b %d %s %s -k",progname,filename_list[0],procs,block_size_list[i],qtmp,vtmp);
			system(command);
		}
	}
	if (do_rdbms == TRUE ||  do_async == TRUE) {
		if(!quiet && do_async == TRUE) {
			printf("\tAsynchronous Disk test: servers min=%d, max=%d \n",aio_min,aio_max);
		}
		else
			printf("\tSynchronous Disk test (regular read/write)\n");
		if(!quiet)printf("\tNo. of processes = %d \n",procs);
		printf("\tI/O type         = %s\n",iotype==SEQUENTIAL?"Sequential":"Random");
		if(!quiet && offset) {
		printf("\tOffset           = %lld\n",offset);

		}
		if(!quiet &&(pure || purish)) {
		pure_readf = (double)procs * (double)read_percent / 100.0;
		pure_read = pure_readf;
		if( pure_readf - (double)pure_read > 0.5)
                pure_read++;
		pure_write = procs - pure_read;
		printf("\tPure processes   = read=%d write=%d\n",pure_read,pure_write);
		}
		if(!quiet) {
		printf("\tBlock size%s     = %ld",block_size_max==1?"  ":"s ",block_size_list[0]);
		for(i=1;i<block_size_max;i++)
			printf(" %d",block_size_list[i]);
		printf("\n");
		}
		printf("\tRead-Write");
		if(read_percent == 100)
			printf("       = Read Only\n");
		else if (read_percent == 0)
			printf("       = Write Only\n");
		else if (read_percent == 50)
			printf("       = Equal read and write\n");
		else if (read_percent > 50)
			printf("Ratio: %d:%d = read mostly\n",read_percent,100 - read_percent);
		else
			printf("Ratio: %d:%d = write mostly\n",read_percent,100 - read_percent);
		actual_percent=read_percent;
		if(!quiet) if(fsyncing == FSYNCING)
			printf("\tSync type:FSYNC = fsync() system call after each write I/O\n");
		else if(fsyncing == OSYNCING)
			printf("\tSync type: OSYNC = file opened with O_SYNC option, system will sync after each write I/O\n");
		else
			printf("\tSync type: none  = just close the file\n");
		if(cio_flag)
			printf("\tFile open() mode = Concurrent I/O mode - O_CIO\n");
		if(dio_flag)
			printf("\tFile open() mode = Direct I/O mode - O_DIRECT\n");
		if(randomise_all_flag)
			printf("\tRandomise buffer = All write buffer content\n");
		else {
			if(randomise_1st_flag)
				printf("\tRandomise buffer = First write buffer content\n");
		}
		if(!quiet) printf("\tNumber of files  = %d\n",filename_max);
		if(!quiet) if(file_size != 0)
			printf("\tFile size        = %lld bytes = %lld KB = %lld MB\n",
				(long long)file_size, 
				(long long)(file_size/1024),
				(long long)(file_size/1024/1024)
				);
			else 
			printf("\tFile size to be determined from the file(s) (raw devices will fail)\n");
		if(!quiet) printf("\tRun time         = %d seconds\n",seconds);
		if(!quiet) printf("\tSnooze %%         = %d percent\n",snooze);
		if(verbose)printf("\tVerbose          = ON\n"); 
		if(logging)printf("\tLogging          = ON\n"); 
		if(!quiet) if(verbose) {
			printf("\tFile %sNames 1=\"%s\"",pure?"Read ":"", filename_list[0]);
			for(i=1;i<filename_max;i++) {
				printf(", %d=\"%s\"",i+1,filename_list[i]);
			}
			printf("\n");
			if(pure) {
				printf("\tFile Write Names 1=\"%s\"",pfilename_list[0]);
				for(i=1;i<pfilename_max;i++) {
					printf(", %d=\"%s\"",i,pfilename_list[i]);
				}
				printf("\n");
			}
		}
		DEBUG1( printf("Multiple processes start %d processes for %d block sizes\n",procs,block_size_max); );
		shm_size = sizeof(struct tdata) * procs;
		SYSCALL( shmid_parallel = shmget(shm_user_key, 
						shm_size, 
						IPC_CREAT | SHM_R | SHM_W | IPC_EXCL) );
		SYSCALL( (int)(shmptr = (struct tdata *)shmat(shmid_parallel,0,0)) );
		if(shmptr == (struct tdata *) 0) {
			printf("failed to get shared memory address\n");
			exit(52);
		}
		attached = 1;
		if(verbose)printf("Run sync() to flush disks before testing\n");
		sync();

		for(bs=0;bs<block_size_max;bs++)  {
			printf("----> Running test with block Size=%d (%dKB) ", 
					block_size_list[bs],
					(int)(block_size_list[bs]/1024));
			for(t=0;t<procs;t++) {
				shmptr[t].status = WAIT;
				shmptr[t].ios = 0;
				shmptr[t].min = 999999.9;
				shmptr[t].max = 0.0;
				shmptr[t].elapsed = 0.0;
				shmptr[t].iotime = 0.0;
				shmptr[t].synctime = 0.0;
			}
			for(t=0;t<procs;t++) {
				if(pure) {
					if(t < pure_read)
						read_percent = 100;
					else
						read_percent = 0;
				}
				fflush(stdout);

				DEBUG1(printf("FORK %d CALLED\n",t););
				if( (pid = fork()) == 0 ) {
					my_id = t; 
					DEBUG1(printf("CHILD %d STARTING PID=%d\n",my_id,getpid()););
					if(getenv("NSTRESS_RANDOM") != NULL) 
						srandom(atoi(getenv("NSTRESS_RANDOM")));
					else
						srandom(getpid());
					for(i=0;shmptr[t].status == WAIT && i<300000 ;i++)
						usleep(100);
					if(shmptr[t].status == WAIT && !debug) {
						printf("\nThread %d bailing out after 30 second as status never went to RUN\n",t);
						exit(9999);
					}

					if(do_async == TRUE)
						aio_rdbms_test(iotype, 
							filename_list[my_id%filename_max], 
							file_size, 
							read_percent, 
							aio_min,
							aio_max,
							block_size_list[bs],
							fsyncing,
							(offset * (off64_t)t) % (off64_t)file_size
							);
					else
						sync_rdbms_test(iotype, 
							(pure && !purish && read_percent == 0) 
							?pfilename_list[my_id%pfilename_max]
							: filename_list[my_id%filename_max], 
							file_size,
							read_percent,
							block_size_list[bs],
							fsyncing,
							snooze,
							(offset * (off64_t)t) % (off64_t)file_size
							);
					
					DEBUG1(printf("CHILD %d EXITING\n",my_id););
					exit(99);
				} else {
					DEBUG1( printf("pid %d forked\n", pid); );
					printf(".");
				}
			}
			printf("\n");

			/* remove shared memory now to ensure a clean stop - it is only marked for removal at the last detach */
			if(attached)
				SYSCALL( shmctl(shmid_parallel,IPC_RMID,(struct shmid_ds*)0) );
			attached = 0;
			for(t=0;t<procs;t++) 
				shmptr[t].status = RUN;

			sleep(seconds);

			for(i=0;i<procs;i++) {
				shmptr[i].status = STOP;
			}

			/* wait for child procs to update shm */
			for(i=0;i<procs;i++) {
				while(shmptr[i].status != DONE)
					usleep(100);
			}

			for(i=0;i<procs;i++)
				SYSCALL( pid = wait( &status) );

			total_ios = 0;
			total_iospersec = 0.0;
			total_mbpersec = 0.0;
			total_kbpersec = 0.0;
			printf("Proc - <-----Disk IO----> | <-----Throughput------> RunTime\n");
			printf(" Num -     TOTAL   IO/sec |    MB/sec       KB/sec  Seconds\n");
			for(i=0;i<procs;i++) {
				printf("%4d - %9d %8.1f | %9.2f %12.2f %6.2f\n", 
							i+1, 
							shmptr[i].ios,
							(double)shmptr[i].ios/shmptr[i].elapsed,
							(double)shmptr[i].ios/shmptr[i].elapsed*block_size_list[bs]/1024/1024,
							(double)shmptr[i].ios/shmptr[i].elapsed*block_size_list[bs]/1024,
							shmptr[i].elapsed
							);
				total_ios += shmptr[i].ios;
				total_iospersec += shmptr[i].ios/shmptr[i].elapsed;
				total_mbpersec += shmptr[i].ios/shmptr[i].elapsed*block_size_list[bs]/1024/1024;
				total_kbpersec += shmptr[i].ios/shmptr[i].elapsed*block_size_list[bs]/1024;
			}
			if(procs > 1) {
				printf("TOTALS %9d %8.1f | %9.2f %12.2f\n", 
						total_ios,
						total_iospersec,
						total_mbpersec,
						total_kbpersec);
				printf("- %s procs=%3d read=%3d%% bs=%3dKB\n", 
					(iotype == SEQUENTIAL)?"Seqential":"Random", procs,actual_percent,block_size_list[bs]/1024);
			}
						
		if(verbose) {
				printf("Proc - Read:Write Rewinds | Response time stats(msecs) | iotime   synctime\n"); 
				printf(" Num -    Ratio   to file |      min     max       avg | seconds  seconds\n"); 
				for(i=0;i<procs;i++) {
					if(shmptr[i].ios == 0)
						printf("%3d No IO performed\n",i);
					else {
						total=shmptr[i].reads + shmptr[i].writes;
						printf("%4d   %5.1f:%-5.1f   %-3d  | %8.3f %8.3f %8.3f | %6.2f  %6.2f\n", 
								i+1,
								shmptr[i].reads/total*100.0,
								shmptr[i].writes/total*100.0,
								shmptr[i].rewinds,
								1000 * shmptr[i].min,
								1000 * shmptr[i].max,
								1000 * shmptr[i].elapsed / shmptr[i].ios,
								shmptr[i].iotime,
								shmptr[i].synctime);
					}
				}
			}
		}
	}
	if(shm_address != 0)
		SYSCALL( shmctl(shmid_data,IPC_RMID,0) );
	return 0;
}
