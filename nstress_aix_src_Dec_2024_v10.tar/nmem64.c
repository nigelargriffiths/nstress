/* nmem64.c part of nstress - a collect of programs to stress test a computer
 * neme64 - allocates large amounts of memory and then updates it to test the memory subsystem
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <strings.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>

long long longlongrange(long long min,long long max)
{
long top;
long bot;
long long longer;
long long ranger;

        top = random();
        bot = random();

        longer = top;
        longer = longer << 31;
        longer = longer + bot;

        ranger = (longer % ((max - min +1LL)) + min);

        return ranger;
}


#define __QUOTESTRING(yyyy) "yyyy"

#define SYSCALL(xxxx) if((xxxx) == -1) { \
perror( "ERROR"); \
fprintf(stderr,"Assert failure: SYSCALL retured  -1:\nFile=%s, Function=%s, Line=%d,\nOperation=\"%s\"\n", __FILE__, __FUNCTION__, __LINE__, __QUOTESTRING(xxxx) ); \
exit(42); \
}


#define READ  4
#define WRITE 5
#define MIXED 6

int interrupted = 0;
char *progname;
int debug = 0;

void sighandler(int x)
{
	interrupted = 1;
}

long
scan( char *startptr, long long max, int rw, int snooze)
{
register char *p;
register char value =  42;
register long ops;
register int rw_type;

        struct timeval start;
        struct timeval now;
        double diff;
        double startsec;
        double nowsec;
        double hundredeth; /* 100ths of a second since we started */


	if(debug) printf("scan( char *startptr=0x%x, long long max=%lld, int rw=%d, int snooze=%d)\n", startptr, max, rw, snooze);
	if(snooze > 0)
		gettimeofday(&start, NULL);
	ops = 0;
	p = startptr;
	interrupted = 0;

	while(! interrupted) {
#ifdef DEBUG
		{
		long long tmp;
		tmp=longlongrange(0,max);
		p = startptr + tmp;
		printf("%lld\n",tmp);
		}
#else
		p = startptr + longlongrange(0,max);
#endif

		if(rw == MIXED)
			rw_type = longlongrange(0,1);
		else 
			rw_type = rw;

		if(rw_type == READ)
			value = *p;
		else
#ifdef FILLPAGES
		{
			switch(longlongrange(1,6)) {
			case 1:
			case 2:
			case 3:
			case 4:
			case 5:  *p = 'a'; 
				break;
			case 6:
			default: *p = 'b'; 
				break;
			}
			/* random is impossible to compress */
			/* *p = (char)random(); */
		}
#else /* TOUCH PAGES */
		{
			*p = value; 
		}
#endif /* FILLPAGES */
		ops++;
                if(snooze > 0) {
                        gettimeofday(&now, NULL);
                        startsec = (double)start.tv_sec +
                                        ((double)start.tv_usec/1000000.0);
                        nowsec = (double)now.tv_sec +
                                        ((double)now.tv_usec/1000000.0);
                        diff = nowsec - startsec;

                        /* printf("diff=%f\n",diff);  */
                        hundredeth = diff * 100.0;
                        /*printf("100ths=%f\n",hundrede th); */
                        if( hundredeth > 100 - snooze) {
                                /*printf("usleep\n") */;
                                usleep(snooze*10000);
                                gettimeofday(&start, NULL);
                        }
                }
	}
	return ops;
}

char *io(int rw)
{
	switch(rw) {
	case READ: return "read";
	case WRITE: return "write";
	default:
	case MIXED: return "mixed";
	}
}

void
measure( long long max, int rw, int secs, int snooze)
{
int i;
int j;
char *p;
char *start;
long ops;
double seconds;
struct timeval begin;
struct timeval end;

	if(debug) printf("measure( long long max=%lld, int rw=%d, int secs=%d, int snooze=%d)\n", max, rw, secs, snooze);
	fflush(0);
	/* printf("Memory size %lld bytes\n",max); */
	start = malloc(max);
	if(start == (char *)0) {
		perror("malloc");
		return;
	}
#ifdef FILLPAGES
	/* pre-write random memory to provide level playing field */
	for(i=0,p=start,j=0;i<max;i++) {
		switch(longlongrange(1,6)) {
		case 1:
		case 2:
		case 3:
		case 4:
		case 5:  *p = 'a'; 
			break;
		case 6:
		default: *p = 'b'; 
			break;
		}
		p++; 
	}
#else /* TOUCH PAGES */
	/* pre-fetch memory to provide level playing field */
	for(i=0,p=start,j=0;i<max;i =i + 1024) {
		j = j + *p;
		p = p + 1024; /* go for four page hits per page */
	}
#endif /* FILLPAGES */
	if(debug) printf("Memory initialised\n", j); 
	/* don't remove the j */
	printf("size %9.2fK %5s - ",max/1024.0, io(rw));
	/* sleep to boost priority */
	sleep(1);
	interrupted=0;
	signal(SIGALRM, sighandler);
	alarm(secs);

	gettimeofday(&begin,0);
	ops = scan(start,max,rw,snooze); /* <= actual work */
	gettimeofday(&end,0);

	seconds = (double)end.tv_sec + (double)end.tv_usec/1000000.0
		- (double)begin.tv_sec + (double)begin.tv_usec/1000000.0;
	
	printf("ops=% 8.0fK, time=% 8.2f ops/s=% 8.0fK\n",
			ops/1000.0,
			seconds,
			ops/seconds/1000.0);
	free(start);
}

void hint(void)
{
        printf("Usage: nmem version %s\n", VERSION);
        printf("Hint: nstress tool to hammer memory (do not use this on production machines)\n");
	printf(" use 1: mallocs memory and then touches the memory pages at random \n");
	printf(" use 2: cycles though memory speed test to determine/guess cache sizes (-c option)\n");
	printf(" output includes memory size used, operations performed, time taken and ops per second\n");
        printf("\n");
        printf("\tnmem -m Mbytes [-d] [-s MaxSeconds] [-z percent][-o \"cmd\"]\n");
        printf("\t\tMbytes     = Size of RAM to use in mega-bytes\n");
        printf("\t\t             For nmem the max is 255 (~256MB) and for nmem64 the max is 2047 (~2GB))\n");
        printf("\t\t-d           switch on debugging output\n");
        printf("\t\tMaxSeconds = maximum time of the test. \n\t\t\tUse this to halt nmem even if you drove your OS to a stand still. \n\t\t\tYou have been warned!\n");
        printf("\t\tpercent    = Snooze percent - nmem sleeps for the percentage of the time\n");
        printf("\t\tcmd        = nmem with pretend to be a process called cmd.\n");
        printf("\t\t             This option must be the last on the line in double quotes\n\n");
        printf("\n\tMemory speed test with increasing memory sizes\n");
        printf("\t- may highlight CPU cache sizes\n");
        printf("\n");
        printf("\tnmem -c [-s MaxSeconds]\n");
        printf("\n");
        printf("\t\tMaxSeconds = maximum time of the test (default 60)\n");
        printf("Example:\n");
        printf("\tnmem -m 250 -s 300      \t - grab and randomly touch 256 MB of memory for 5 minutes\n");
        printf("\tnmem -m 250 -s 300 -z 80\t - as above but slower, sleep 80%% of the time\n");
        printf("\tnmem -c -s 600          \t - cycle through tests (maximum of 10 minutes)\n");
        printf("\tnmem -m 6 -o \"sally -x\"  \t - Use 6 MB pretend to be process sally with parameter -x\n");
        printf("\n");
        printf("If your OS complains about the size of memory use you hit your ulimit\n");
        printf("\t For 256MB+ try: ulimit -d unlimited \n");
        printf("\n");
        exit(1);
}

int
main(int argc,char **argv)
{
	long i;
	long j;
	int ch;
        char command[256];
	long mbytes = 0;
	long long bytes = 0;
	int seconds = 60;
	int cycle = 0;
	int seconds_so_far = 0;
        int snooze = 0;


        progname = argv[0];

        while ((ch = getopt(argc, argv, "h?dk:s:m:o:cz:")) != -1)
        {
                switch(ch)
                {
                case '?':
                case 'h': hint(); break;
                case 'd': debug++; break;
                case 'm': mbytes = abs(atol(optarg)); break;
		case 'c': cycle++; break;
                case 's': seconds = abs(atoi(optarg)); break;
                case 'z': snooze = abs(atoi(optarg)); break;

                case 'o':       
			if(debug)
				printf("link(%s,%s)\n",progname,optarg);
			SYSCALL(link(progname,optarg) );
			switch(fork())
			{
			case -1: perror("fork failed"); break;
			case 0: /* child */
				strcpy(command,optarg); /* save cmd */
				argv[0] = command;
				argv[optind-1] = 0; /* remove this optio n */
				argv[optind-2] = 0;
				argv[argc] = 0;
				if(debug) {
					printf("about to exec command \"%s\"\n",command);
					for(i=0;i <argc; i++)
						printf("argv[%ld]=%s\n",i,argv[i]);
				}
				SYSCALL( execv(command,argv) );
				break;
			default: /* parent */
				break;
			}
			sleep(6); /* to allow other process to start before deleting the link */
			SYSCALL( unlink(optarg) );
			return 0;

                }
        }

	if(debug) printf("mbytes=%ld\n",mbytes);
	if(cycle == 0 && mbytes == 0)
		hint();
	if(cycle) {
	    while( seconds_so_far < seconds) {
		setpriority(PRIO_PROCESS,0,-20);
		for(j=5;j<120 && seconds_so_far<seconds;j +=5) {
			printf("Memory Test:\n");
			for(i = 1024; i <= 128*1024*1024 && seconds_so_far<seconds; i *= 2) {
				measure( i,READ, j, snooze);
				measure( i,WRITE,j, snooze);
				measure( i,MIXED,j, snooze);
				seconds_so_far += j*2;
			}
		}
	    }
	}
	else {

#define MAXGB 1024*128

		if( 0 >= mbytes || mbytes >= MAXGB) {
			printf("need to supply the -m MB parameter (1 to %d)\n",MAXGB);
			hint();
		}
		if(debug) printf("mbytes=%ld\n",mbytes);
		bytes = (long long)mbytes * (long long)1024 * (long long)1024;
		if(debug) printf("bytes=%lld\n",bytes);
		while( seconds_so_far<seconds) {
			measure( bytes, MIXED, seconds+1, snooze);
			seconds_so_far += seconds+1;
		}
	}
	return 0;
}
