/* randomcheck.c.c part of nstress - a collect of programs to stress test a computer
 * Simpler check for randomness from a file of numbers
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */



#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <strings.h>

#define BUCKETS 1024

long long i;
long long value;
long long count;
long long negative;
long long toolarge;
long long ignore;
long long bucket[BUCKETS];

int main(int argc,char **argv)
{
	FILE *fp;
	char buf[1025];

	if((fp = fopen("checkfile","r")) == NULL) {
		perror("can't open nmem_log");
		exit(42);
	}

	while( fgets(buf,1024, fp) != NULL) {
		buf[strlen(buf)-1] = 0;
		/*ignore none lseek lines */
		if(strncmp("lseek64",buf, 7)) {
			ignore++;
			continue; 
		}
		count++;

		value=atoll(&buf[8]);

/*printf("value=%lld string=[%s]\n",value,buf);/* */
		if(value <0LL) { 
			negative++; 
			continue;
		}

		for(i=0;i<BUCKETS-1;i++) {
			if(( value >      i * 1024LL * 1024LL * 256LL) &&
			   ( value <= (i+1) * 1024LL * 1024LL * 256LL) )
			{
				bucket[i]++;
				continue;
			}
		}
		if( value >= (i+1) * 1024LL * 1024LL * 256LL) 
			toolarge++;
	}

	printf("lines ignored   =%lld\n",ignore);
	printf("lseek lines     =%lld\n",count);
	printf("negative numbers=%lld\n",negative);
	printf("too high numbers=%lld\n",toolarge);
	
	for(i=0;i<BUCKETS-1;i++) {
		if( bucket[i] > 0)
		printf("bucket[%3lld]  %6lldMB -> %6lldMB = %lld\n",
				i,
				    i * 256LL,
				(i+1) * 256LL,
				bucket[i]);
	}
}
