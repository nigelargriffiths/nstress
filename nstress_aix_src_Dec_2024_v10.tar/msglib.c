/* msglib.c part of nstress - a collect of programs to stress test a computer
 * Message queues library function part of IPC tests
 * (C) Copyright 2000 Nigel Griffiths

 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 */

#define VERSION "10.0"

#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

char *strcpy();
char *strncpy();

#define MESSAGE_LENGTH	10000

struct message {
		long msg_type;
		char msg_buffer[MESSAGE_LENGTH];
		} msg;

int message_id;

void message_create(int key)
{
key_t message_key;
int   message_flag;

        if(key == 0)
                message_key = IPC_PRIVATE;
        else
                message_key = key;
	message_flag = 0666 | IPC_CREAT;

	if((message_id = msgget(message_key,message_flag)) == -1)
	{
		perror("msgget()");
		exit(1);
	}
}

void message_fetch(int key)
{
key_t message_key;
int   message_flag;

	message_key = key;
	message_flag = 0666;

	if((message_id = msgget(message_key,message_flag)) == -1)
	{
		perror("msgget()");
		exit(2);
	}
}

void message_send(int type, char *buf, int size)
{
int message_flag;

	msg.msg_type = type;
	(void)strcpy(msg.msg_buffer, buf);
	message_flag =0;

	if(msgsnd(message_id,&msg,size,message_flag) != 0)
	{
		perror("msgsnd()");
		exit(1);
	}
}


int message_recv(int type, char *buf, int size)
{
int message_flag = 0;
int message_count;

	if((message_count = msgrcv(message_id,&msg,size,type,message_flag)) < 0)
	{
		perror("msgrcv()");
		exit(1);
	}
	(void)strncpy(buf, msg.msg_buffer, (long unsigned int)message_count);
	buf[message_count] = 0;
	return message_count;
}

void message_delete(int report_error)
{
int ret = msgctl(message_id,IPC_RMID,0);
	if( report_error && ret == -1)
	{
		perror("msgctl()");
		exit(2);
	}
}
